package API;

import android.app.Activity;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RemindAPI {
    private Activity activityStart;
    private Remind remind;

    public RemindAPI(Activity activityStart, Remind remind) {
        this.activityStart = activityStart;
        this.remind = remind;
    }

    public void addRemind() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.ADD_REMIND_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("v_id", remind.getV_id());
                params.put("type", remind.getType());
                params.put("date", remind.getDate());
                params.put("note", remind.getNote());
                params.put("calender",String.valueOf(remind.getC_id()));

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void updateRemind() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.UPDATE_REMIND_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("r_id", String.valueOf(remind.getR_id()));
                params.put("type", remind.getType());
                params.put("date", remind.getDate());
                params.put("note", remind.getNote());
                params.put("calender",String.valueOf(remind.getC_id()));

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void deleteRemind() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.DELETE_REMIND_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("r_id", String.valueOf(remind.getR_id()));

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }
}
