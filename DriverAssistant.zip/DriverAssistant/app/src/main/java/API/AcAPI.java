package API;

import android.app.Activity;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AcAPI {
    private Activity activityStart;
    private Ac activity;

    public AcAPI(Activity activityStart, Ac activity) {
        this.activityStart = activityStart;
        this.activity = activity;
    }

    public void addAc() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.ADD_ACTIVITY_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                                activityStart.finish();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("name", activity.getName());
                params.put("type", activity.getType());
                params.put("date", activity.getDate());
                params.put("time", activity.getTime());
                params.put("odometer", String.valueOf(activity.getOdometer()));
                params.put("price",String.valueOf(activity.getPrice()));
                params.put("money",String.valueOf(activity.getMoney()));
                params.put("liter",String.valueOf(activity.getLiter()));
                params.put("location",activity.getLocation());
                params.put("v_id",activity.getV_id());
                params.put("note", activity.getNote());

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void updateAc() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.UPDATE_ACTIVITY_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("type", activity.getType());
                params.put("date", activity.getDate());
                params.put("time", activity.getTime());
                params.put("odometer", String.valueOf(activity.getOdometer()));
                params.put("price",String.valueOf(activity.getPrice()));
                params.put("money",String.valueOf(activity.getMoney()));
                params.put("liter",String.valueOf(activity.getLiter()));
                params.put("location",activity.getLocation());
                params.put("a_id",String.valueOf(activity.getA_id()));
                params.put("note", activity.getNote());

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void deleteAc() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.DELETE_ACTIVITY_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("a_id", String.valueOf(activity.getA_id()));

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

//    public void getAcs() {
//
//        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.GET_ACTIVITY_URL,
//                new Response.Listener<String>() {
//                    @Override
//                    public void onResponse(String response) {
//                        try {
//                            JSONObject jsonObject = new JSONObject(response);
//                            if (jsonObject.getBoolean("status")) {
//                                JSONArray result = jsonObject.getJSONArray("result");
//                                for(int i = 0;i<result.length();i++) {
//                                    JSONObject data = result.getJSONObject(i);
//                                    Remind r = new Remind(data.getInt("r_id"),
//                                            data.getString("type"),
//                                            data.getString("date"),
//                                            data.getString("note"),
//                                            data.getString("v_id"));
//
//                                }
//                            } else {
//                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
//                                        Toast.LENGTH_SHORT).show();
//                            }
//                        } catch (JSONException e) {
//                            e.printStackTrace();
//                        }
//                    }
//                },
//                new Response.ErrorListener() {
//                    @Override
//                    public void onErrorResponse(VolleyError error) {
//                        Toast.makeText(activityStart, "Failed: " + error.toString(),
//                                Toast.LENGTH_SHORT).show();
//                    }
//                }
//        ) {
//            @Override
//            protected Map<String, String> getParams() {
//                Map<String, String> params = new HashMap<String, String>();
//                params.put("a_id", String.valueOf(activity.getA_id()));
//
//                return params;
//            }
//        };
//        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
//    }
}
