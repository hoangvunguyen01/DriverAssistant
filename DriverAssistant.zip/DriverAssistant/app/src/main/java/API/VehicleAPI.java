package API;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.gson.JsonObject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class VehicleAPI {
    private Activity activityStart;
    private Class activityEnd;
    private Vehicle vehicle;

    public VehicleAPI(Activity activityStart, Class activityEnd, Vehicle vehicle) {
        this.activityStart = activityStart;
        this.activityEnd = activityEnd;
        this.vehicle = vehicle;
    }

    public VehicleAPI(Activity activityStart, Vehicle vehicle) {
        this.activityStart = activityStart;
        this.vehicle = vehicle;
    }

    public void addVehicle(boolean screenDK, User user) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.ADD_VEHICLE_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                                if(screenDK) {
                                    Intent intent1 = new Intent(activityStart,activityEnd);
                                    intent1.putExtra("User",user);
                                    intent1.putExtra("Vehicle",vehicle);
                                    activityStart.startActivity(intent1);
                                    activityStart.finish();
                                } else {
                                    activityStart.setResult(Activity.RESULT_OK);
                                    activityStart.finish();
                                }
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("v_id", vehicle.getV_id());
                params.put("type", vehicle.getType());
                params.put("v_name", vehicle.getV_name());
                params.put("producer", vehicle.getProducer());
                params.put("icon", String.valueOf(vehicle.getIcon()));
                params.put("capacity", String.valueOf(vehicle.getCapacity()));
                params.put("username", vehicle.getUsername());

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void updateVehicle() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.UPDATE_VEHICLE_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("v_id", vehicle.getV_id());
                params.put("v_name", vehicle.getV_name());
                params.put("capacity", String.valueOf(vehicle.getCapacity()));

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void deleteVehicle() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.DELETE_VEHICLE_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("v_id", vehicle.getV_id());

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }
}