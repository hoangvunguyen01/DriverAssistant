package API;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.Serializable;
import java.util.Objects;

public class Vehicle implements Serializable {
    private String v_id;
    private String type;
    private String v_name;
    private String producer;
    private int icon;
    private float capacity;
    private String username;

    public Vehicle(String v_id) {
        this.v_id = v_id;
    }

    public Vehicle(String v_id, String type, String v_name, String producer, int icon, float capacity, String username) {
        this.v_id = v_id;
        this.type = type;
        this.v_name = v_name;
        this.producer = producer;
        this.icon = icon;
        this.capacity = capacity;
        this.username = username;
    }

    public String getV_id() {
        return v_id;
    }

    public void setV_id(String v_id) {
        this.v_id = v_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getV_name() {
        return v_name;
    }

    public void setV_name(String v_name) {
        this.v_name = v_name;
    }

    public String getProducer() {
        return producer;
    }

    public void setProducer(String producer) {
        this.producer = producer;
    }

    public float getCapacity() {
        return capacity;
    }

    public void setCapacity(float capacity) {
        this.capacity = capacity;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Vehicle vehicle = (Vehicle) o;
        return  Objects.equals(username, vehicle.username) &&
                Objects.equals(v_id, vehicle.v_id) &&
                Objects.equals(type, vehicle.type) &&
                Objects.equals(v_name, vehicle.v_name) &&
                Objects.equals(producer, vehicle.producer) &&
                capacity == vehicle.capacity &&
                icon == vehicle.icon;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {
        return Objects.hash(v_id, type, v_name, producer,icon, capacity, username);
    }
    @Override
    public String toString() {
        return "Vehicle{" +
                "v_id='" + v_id + '\'' +
                ", type='" + type + '\'' +
                ", v_name='" + v_name + '\'' +
                ", producer='" + producer + '\'' +
                ", capacity='" + capacity + '\'' +
                '}';
    }

}
