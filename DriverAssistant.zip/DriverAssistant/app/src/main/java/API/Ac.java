package API;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.Serializable;
import java.util.Objects;

public class Ac implements Serializable {
    private int a_id;
    private String name;
    private String date;
    private String time;
    private float odometer = 0;
    private String type;
    private float price = 0;
    private float money;
    private float liter = 0;
    private String location = "";
    private String note;
    private String v_id;

    public Ac(int a_id, String name, String date, String time, float odometer, String type,
                    float price, float money, float liter, String location, String note, String v_id) {
        this.a_id = a_id;
        this.name = name;
        this.date = date;
        this.time = time;
        this.odometer = odometer;
        this.type = type;
        this.price = price;
        this.money = money;
        this.liter = liter;
        this.location = location;
        this.note = note;
        this.v_id = v_id;
    }

    public Ac(String name, String date, String time, float odometer, String type, float price,
                    float money, float liter, String location, String note, String v_id) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.odometer = odometer;
        this.type = type;
        this.price = price;
        this.money = money;
        this.liter = liter;
        this.location = location;
        this.note = note;
        this.v_id = v_id;
    }

    public Ac(String name, String date, String time, float odometer, String type, float money,
              String location, String note,String v_id) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.odometer = odometer;
        this.type = type;
        this.money = money;
        this.location = location;
        this.note = note;
        this.v_id = v_id;

    }

    public Ac(String name, String date, String time, String type, float money, String note, String v_id) {
        this.name = name;
        this.date = date;
        this.time = time;
        this.type = type;
        this.money = money;
        this.note = note;
        this.v_id = v_id;
    }



    public int getA_id() {
        return a_id;
    }

    public void setA_id(int a_id) {
        this.a_id = a_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public float getOdometer() {
        return odometer;
    }

    public void setOdometer(float odometer) {
        this.odometer = odometer;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public float getMoney() {
        return money;
    }

    public void setMoney(float money) {
        this.money = money;
    }

    public float getLiter() {
        return liter;
    }

    public void setLiter(float liter) {
        this.liter = liter;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getV_id() {
        return v_id;
    }

    public void setV_id(String v_id) {
        this.v_id = v_id;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Ac activity = (Ac) o;
        return a_id == activity.a_id &&
                Objects.equals(v_id, activity.v_id) &&
                Objects.equals(type, activity.type) &&
                Objects.equals(name, activity.name) &&
                Objects.equals(time, activity.time) &&
                Objects.equals(date, activity.date) &&
                Objects.equals(note, activity.note) &&
                Objects.equals(location, activity.location) &&
                odometer == activity.odometer &&
                price == activity.price &&
                money == activity.money &&
                liter == activity.liter;

    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {
        return Objects.hash(a_id, name, date, time, odometer, type, price, money, liter,
                location, note, v_id);
    }
    @Override
    public String toString() {
        return "Activity{" +
                "a_id='" + a_id + '\'' +
                ", name='" + name + '\'' +
                ", date='" + date + '\'' +
                ", time='" + time + '\'' +
                ", odometer='" + odometer + '\'' +
                ", type='" + type + '\'' +
                ", price='" + price + '\'' +
                ", money='" + money + '\'' +
                ", liter='" + liter + '\'' +
                ", location='" + location + '\'' +
                ", note='" + note + '\'' +
                ", v_id='" + v_id + '\'' +
                '}';
    }
}
