package API;

public class URL {
    private static final String ROOT_URL = "http://192.168.0.102/drivers-API/";
    public static final String GET_USER_URL = ROOT_URL + "get-user.php";
    public static final String UPDATE_USER_URL = ROOT_URL + "update-user.php";
    public static final String ADD_USER_URL = ROOT_URL + "add-user.php";
    public static final String GET_VEHICLE_URL = ROOT_URL + "get-vehicles.php";
    public static final String UPDATE_VEHICLE_URL = ROOT_URL + "update-vehicle.php";
    public static final String ADD_VEHICLE_URL = ROOT_URL + "add-vehicle.php";
    public static final String DELETE_VEHICLE_URL = ROOT_URL + "delete-vehicle.php";
    public static final String GET_REMIND_URL = ROOT_URL + "get-reminds.php";
    public static final String UPDATE_REMIND_URL = ROOT_URL + "update-remind.php";
    public static final String ADD_REMIND_URL = ROOT_URL + "add-remind.php";
    public static final String DELETE_REMIND_URL = ROOT_URL + "delete-remind.php";
    public static final String GET_ACTIVITY_URL = ROOT_URL + "get-activitys.php";
    public static final String UPDATE_ACTIVITY_URL = ROOT_URL + "update-activity.php";
    public static final String ADD_ACTIVITY_URL = ROOT_URL + "add-activity.php";
    public static final String DELETE_ACTIVITY_URL = ROOT_URL + "delete-activity.php";
    public static final String GET_PHONE_URL = ROOT_URL + "get-phones.php";
}
