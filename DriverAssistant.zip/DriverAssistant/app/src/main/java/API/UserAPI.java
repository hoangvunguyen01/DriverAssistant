package API;

import android.app.Activity;
import android.content.Intent;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class UserAPI {
    private Activity activityStart;
    private Class activityEnd;
    private User user;

    public UserAPI(Activity activityStart, Class activityEnd, User user) {
        this.activityStart = activityStart;
        this.activityEnd = activityEnd;
        this.user = user;
    }

    public UserAPI(Activity activityStart, Class activityEnd) {
        this.activityStart = activityStart;
        this.activityEnd = activityEnd;
    }

    public UserAPI(Activity activityStart, User user) {
        this.activityStart = activityStart;
        this.user = user;
    }

    public void checkUser(String Username, String Password) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.GET_USER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                JSONObject data = jsonObject.getJSONObject("result");
                                user = new User(data.getString("username"),
                                        data.getString("password"),
                                        data.getString("fullname"),
                                        data.getString("email"),
                                        data.getString("phone"));
                                Intent intent = new Intent(activityStart, activityEnd);
                                intent.putExtra("User",user);
                                activityStart.startActivityForResult(intent,100);
                            }
                            else {
                                String result = jsonObject.getString("result");
                                Toast.makeText(activityStart,result,Toast.LENGTH_SHORT).show();
                            }
                        } catch(JSONException e){
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(activityStart,"Đăng nhập không thành công!",
                        Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", Username);
                params.put("password", Password);
                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void addUser() {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.ADD_USER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart, jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(activityStart, activityEnd);
                                intent.putExtra("User",user);
                                intent.putExtra("DK",true);
                                activityStart.startActivity(intent);
                                activityStart.finish();
                            } else {
                                Toast.makeText(activityStart, "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", user.getUsername());
                params.put("password", user.getPassword());
                params.put("fullname", user.getFullname());
                params.put("email", user.getEmail());
                params.put("phone", user.getPhone());

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }

    public void updateUser(Intent intent) {
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.UPDATE_USER_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                Toast.makeText(activityStart,
                                        jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                                intent.putExtra("USER",user);
                                activityStart.setResult(Activity.RESULT_FIRST_USER,intent);
                                activityStart.finish();
                            } else {
                                Toast.makeText(activityStart, "Failed: " +
                                                jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(activityStart, "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", user.getUsername());
                params.put("password", user.getPassword());
                params.put("fullname", user.getFullname());
                params.put("email", user.getEmail());
                params.put("phone", user.getPhone());

                return params;
            }
        };
        RequestHandler.getInstance(activityStart).addToRequestQueue(postRequest);
    }
}
