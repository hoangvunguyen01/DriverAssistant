package API;

import android.os.Build;

import androidx.annotation.RequiresApi;

import java.io.Serializable;
import java.util.Objects;

public class Remind implements Serializable {
    private int r_id;
    private String type;
    private String date;
    private String note;
    private String v_id;
    private long c_id;

    public Remind(int r_id, String type, String date, String note, String v_id, long c_id) {
        this.r_id = r_id;
        this.type = type;
        this.date = date;
        this.note = note;
        this.v_id = v_id;
        this.c_id = c_id;
    }

    public Remind(String type, String date, String note, String v_id, long c_id) {
        this.type = type;
        this.date = date;
        this.note = note;
        this.v_id = v_id;
        this.c_id = c_id;
    }

    public Remind(int r_id, String type, String date, String note, String v_id) {
        this.r_id = r_id;
        this.type = type;
        this.date = date;
        this.note = note;
        this.v_id = v_id;
    }

    public Remind(String type, String date, String note, String v_id) {
        this.type = type;
        this.date = date;
        this.note = note;
        this.v_id = v_id;
    }

    public int getR_id() {
        return r_id;
    }

    public void setR_id(int r_id) {
        this.r_id = r_id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public String getV_id() {
        return v_id;
    }

    public void setV_id(String v_id) {
        this.v_id = v_id;
    }

    public long getC_id() {
        return c_id;
    }

    public void setC_id(long c_id) {
        this.c_id = c_id;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Remind remind = (Remind) o;
        return r_id == remind.r_id &&
                Objects.equals(date, remind.date) &&
                Objects.equals(type, remind.type) &&
                Objects.equals(note, remind.note) &&
                Objects.equals(v_id, remind.v_id) &&
                c_id == remind.c_id;
    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    @Override
    public int hashCode() {
        return Objects.hash(r_id, type, date, note, v_id);
    }
    @Override
    public String toString() {
        return "Remind{" +
                "r_id='" + r_id + '\'' +
                ", type='" + type + '\'' +
                ", date='" + date + '\'' +
                ", note='" + note + '\'' +
                ", v_id='" + v_id + '\'' +
                '}';
    }
}
