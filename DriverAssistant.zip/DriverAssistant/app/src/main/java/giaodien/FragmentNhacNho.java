package giaodien;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.driverassistant.MainActivity;
import com.example.driverassistant.R;
import com.example.driverassistant.XemLichSuHoatDongActivity;
import com.example.driverassistant.XemNhacNhoActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import API.Ac;
import API.Remind;
import API.RequestHandler;
import API.URL;
import API.User;
import API.Vehicle;
import adaptor.XemNhacNhoAdapter;

public class FragmentNhacNho extends Fragment {
    private ArrayList<Remind> list;
    private RecyclerView rvList;
    private LinearLayout linearNhacNhoEmpty;
    private User user;
    private Vehicle vehicle;
    private XemNhacNhoAdapter adapter;
    private int positionNn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_nhac_nho, container, false);
        ((MainActivity) getActivity()).getSupportActionBar().setTitle("Nhắc nhở");

        AnhXa(view);

        Bundle bundle = getArguments();
        if(bundle != null) {
            user = (User) bundle.getSerializable("User");
            vehicle = (Vehicle) bundle.getSerializable("Vehicle");
        }

        list = new ArrayList<>();
        adapter = new XemNhacNhoAdapter(this,list);
        getReminds();

        rvList.setLayoutManager(new LinearLayoutManager(getActivity(),
                LinearLayoutManager.VERTICAL, false));
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(),
                DividerItemDecoration.VERTICAL));
        rvList.setAdapter(adapter);



        return view;
    }

    private void AnhXa(View view) {
        rvList            = (RecyclerView) view.findViewById(R.id.rv_nhac_nho);
        linearNhacNhoEmpty  = (LinearLayout) view.findViewById(R.id.linear_nhac_nho_empty);
    }

    public void moXemNhacNho(int position) {
        positionNn = position;
        Intent intent = new Intent(getActivity(), XemNhacNhoActivity.class);
        intent.putExtra("Remind",list.get(position));
        startActivityForResult(intent,190);
    }

    public void getReminds() {
        list.clear();
        List<Remind> remindList = new ArrayList<>();
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.GET_REMIND_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                JSONArray result = jsonObject.getJSONArray("result");
                                for(int i = 0;i<result.length();i++) {
                                    JSONObject data = result.getJSONObject(i);
                                    Remind r = new Remind(data.getInt("r_id"),
                                            data.getString("type"),
                                            data.getString("date"),
                                            data.getString("note"),
                                            data.getString("v_id"),
                                            data.getLong("calender"));
                                    list.add(r);
                                }
                                adapter.setList(list);
                                adapter.notifyDataSetChanged();
                                if (list.size() > 0) {
                                    rvList.setVisibility(View.VISIBLE);
                                    linearNhacNhoEmpty.setVisibility(View.GONE);
                                } else {
                                    rvList.setVisibility(View.GONE);
                                    linearNhacNhoEmpty.setVisibility(View.VISIBLE);
                                }

                            } else {
                                Toast.makeText(getActivity(), "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("v_id", vehicle.getV_id());

                return params;
            }
        };
        RequestHandler.getInstance(getActivity()).addToRequestQueue(postRequest);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 190 && resultCode == Activity.RESULT_OK) {
            list.remove(positionNn);
            list.add(positionNn,(Remind)data.getSerializableExtra("REMIND"));
            adapter.notifyDataSetChanged();
        } else if(requestCode == 190 && resultCode == Activity.RESULT_CANCELED) {
            list.remove(positionNn);
            adapter.notifyDataSetChanged();
        }
    }
}
