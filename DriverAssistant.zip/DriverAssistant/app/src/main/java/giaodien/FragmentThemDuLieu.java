package giaodien;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.Nullable;

import API.RequestHandler;
import API.URL;
import API.User;
import API.Vehicle;
import cachoatdong.ChiPhiActivity;
import cachoatdong.DoNhienLieuActivity;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.driverassistant.MainActivity;
import cachoatdong.NhacNhoActivity;
import com.example.driverassistant.R;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import cachoatdong.SuaChuaActivity;
import cachoatdong.ThayDungDichActivity;
import cachoatdong.ThuNhapActivity;

public class FragmentThemDuLieu extends Fragment implements View.OnClickListener {

    private LinearLayout linearDoXang;
    private LinearLayout linearThayDungDich;
    private LinearLayout linearThuNhap;
    private LinearLayout linearChiPhi;
    private LinearLayout linearSuaChua;
    private LinearLayout linearNhacNho;
    private User user;
    private Vehicle vehicle;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_them_du_lieu, container, false);
        ((MainActivity) getActivity()).getSupportActionBar().setTitle("Thêm thông tin");

        AnhXa(view);

        Bundle bundle = getArguments();
        if(bundle != null) {
            user = (User) bundle.getSerializable("User");
            vehicle = (Vehicle) bundle.getSerializable("Vehicle");
        }

        linearDoXang.setOnClickListener(this);
        linearThayDungDich.setOnClickListener(this);
        linearThuNhap.setOnClickListener(this);
        linearChiPhi.setOnClickListener(this);
        linearSuaChua.setOnClickListener(this);
        linearNhacNho.setOnClickListener(this);

        return view;
    }

    private void AnhXa(View view) {
        linearDoXang = (LinearLayout) view.findViewById(R.id.linear_do_xang);
        linearThayDungDich = (LinearLayout) view.findViewById(R.id.linear_thay_dung_dich);
        linearThuNhap = (LinearLayout) view.findViewById(R.id.linear_thu_nhap);
        linearChiPhi = (LinearLayout) view.findViewById(R.id.linear_chi_phi);
        linearSuaChua = (LinearLayout) view.findViewById(R.id.linear_sua_chua);
        linearNhacNho = (LinearLayout) view.findViewById(R.id.linear_nhac_nho);
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.linear_do_xang:
                intent = new Intent(getActivity(), DoNhienLieuActivity.class);
                intent.putExtra("User",user);
                intent.putExtra("Vehicle",vehicle);
                startActivity(intent);
                break;

            case R.id.linear_thay_dung_dich:
                intent = new Intent(getActivity(), ThayDungDichActivity.class);
                intent.putExtra("User",user);
                intent.putExtra("Vehicle",vehicle);
                startActivity(intent);
                break;

            case R.id.linear_thu_nhap:
                intent = new Intent(getActivity(), ThuNhapActivity.class);
                intent.putExtra("User",user);
                intent.putExtra("Vehicle",vehicle);
                startActivity(intent);
                break;

            case R.id.linear_chi_phi:
                intent = new Intent(getActivity(), ChiPhiActivity.class);
                intent.putExtra("User",user);
                intent.putExtra("Vehicle",vehicle);
                startActivity(intent);
                break;

            case R.id.linear_sua_chua:
                intent = new Intent(getActivity(), SuaChuaActivity.class);
                intent.putExtra("User",user);
                intent.putExtra("Vehicle",vehicle);
                startActivity(intent);
                break;

            case R.id.linear_nhac_nho:
                intent = new Intent(getActivity(), NhacNhoActivity.class);
                intent.putExtra("User",user);
                intent.putExtra("Vehicle",vehicle);
                startActivity(intent);
                break;

        }
    }
}
