package giaodien;

import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.example.driverassistant.MainActivity;
import com.example.driverassistant.R;
import com.example.driverassistant.XemLichSuHoatDongActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import API.Ac;
import API.RequestHandler;
import API.URL;
import API.User;
import API.Vehicle;
import adaptor.LichSuHoatDongAdapter;

public class FragmentLichSu extends Fragment {
    private static final int REQUEST_XEM_LICH_SU_HOAT_DONG = 189;

    private ArrayList<Ac> list;
    private RecyclerView rvList;
    private LinearLayout linearLichSuEmpty;
    private TextView xe;
    private ImageView icon;
    private User user;
    private Vehicle vehicle;
    private LichSuHoatDongAdapter adapter;
    private int positionAc;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_lich_su, container, false);
        ((MainActivity) getActivity()).getSupportActionBar().setTitle("Lịch sử");

        AnhXa(view);

        Bundle bundle = getArguments();
        if(bundle != null) {
            user = (User) bundle.getSerializable("User");
            vehicle = (Vehicle) bundle.getSerializable("Vehicle");
        }

        xe.setText(vehicle.getV_name());
        if(vehicle.getType().equals("Xe máy")) {
            icon.setImageResource(R.drawable.ic_moto);
        } else if(vehicle.getType().equals("Xe hơi")) {
            icon.setImageResource(R.drawable.ic_oto);
        } else if(vehicle.getType().equals("Xe tải")) {
            icon.setImageResource(R.drawable.ic_truck);
        }



        list = new ArrayList<>();

        adapter = new LichSuHoatDongAdapter(this,list);
        getAcs();
        rvList.setLayoutManager(new LinearLayoutManager(getActivity(),
                LinearLayoutManager.VERTICAL, false));
        rvList.addItemDecoration(new DividerItemDecoration(getActivity(),
                DividerItemDecoration.VERTICAL));
        rvList.setAdapter(adapter);




        return view;
    }

    private void AnhXa(View view) {
        rvList              = (RecyclerView) view.findViewById(R.id.rv_lich_su);
        linearLichSuEmpty   = (LinearLayout) view.findViewById(R.id.linear_lich_su_empty);
        xe                  = (TextView) view.findViewById(R.id.tv_pt);
        icon                = (ImageView) view.findViewById(R.id.img_pt);
    }

    public void moXemLichSuHoatDong(int position) {
        positionAc = position;
        Intent intent = new Intent(getActivity(), XemLichSuHoatDongActivity.class);
        intent.putExtra("Ac", list.get(position));
        startActivityForResult(intent,REQUEST_XEM_LICH_SU_HOAT_DONG);
    }

    public void getAcs() {
        list.clear();
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.GET_ACTIVITY_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                JSONArray result = jsonObject.getJSONArray("result");
                                for(int i = 0;i<result.length();i++) {
                                    JSONObject data = result.getJSONObject(i);
                                    Ac a = new Ac(data.getInt("a_id"),
                                            data.getString("name"),
                                            data.getString("date"),
                                            data.getString("time"),
                                            Float.parseFloat(data.getString("odometer")),
                                            data.getString("type"),
                                            Float.parseFloat(data.getString("price")),
                                            Float.parseFloat(data.getString("money")),
                                            Float.parseFloat(data.getString("liter")),
                                            data.getString("location"),
                                            data.getString("note"),
                                            data.getString("v_id"));
                                        list.add(a);
                                }
                                if (list.size() < 1) {
                                    rvList.setVisibility(View.GONE);
                                    linearLichSuEmpty.setVisibility(View.VISIBLE);
                                } else {
                                    linearLichSuEmpty.setVisibility(View.GONE);
                                    rvList.setVisibility(View.VISIBLE);
                                }
                                adapter.setList(list);
                                adapter.notifyDataSetChanged();
                            } else {
                                Toast.makeText(getActivity(), "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                                Log.e("TAG","Failed");
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getActivity(), "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                        Log.e("TAG",error.toString());
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("v_id", vehicle.getV_id());

                return params;
            }
        };
        RequestHandler.getInstance(getActivity()).addToRequestQueue(postRequest);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 189 && resultCode == Activity.RESULT_OK) {
            list.remove(positionAc);
            list.add(positionAc,(Ac)data.getSerializableExtra("AC"));
            adapter.notifyDataSetChanged();
        } else if(requestCode == 189 && resultCode == Activity.RESULT_CANCELED) {
            list.remove(positionAc);
            adapter.notifyDataSetChanged();
        }
    }
}
