package cachoatdong;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.driverassistant.NetWorkChangedListener;
import com.example.driverassistant.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import API.Ac;
import API.AcAPI;
import API.User;
import API.Vehicle;

public class ThuNhapActivity extends AppCompatActivity {

    private EditText edNgay;
    private EditText edGio;
    private EditText edLoaiThuNhap;
    private EditText edTongTien;
    private EditText edGhiChu;
    private User user;
    private Vehicle vehicle;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thu_nhap);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();
        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("User");
        vehicle = (Vehicle) intent.getSerializableExtra("Vehicle");
        setNgayVaGio();

        edNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int ngay = calendar.get(Calendar.DATE);
                int thang = calendar.get(Calendar.MONTH);
                int nam = calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog = new DatePickerDialog(ThuNhapActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        calendar.set(year, month, dayOfMonth);
                        edNgay.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, nam, thang, ngay);

                datePickerDialog.show();
            }
        });

        edGio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int gio = calendar.get(Calendar.HOUR_OF_DAY);
                int phut = calendar.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(ThuNhapActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
                        calendar.set(0,0,0,hourOfDay,minute);
                        edGio.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, gio, phut, true);

                timePickerDialog.show();
            }
        });

        edLoaiThuNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] listItems = new String[]{"Đưa rước hành khách", "Vận chuyển hàng hóa", "Giao đồ ăn"};
                AlertDialog.Builder builder = new AlertDialog.Builder(ThuNhapActivity.this);
                builder.setTitle("Chọn thu nhập");

                builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        edLoaiThuNhap.setText(listItems[which]);
                        dialog.dismiss();
                    }
                });
                builder.setCancelable(true);
                AlertDialog dialog = builder.create();

                dialog.show();
            }
        });

    }

    private void AnhXa() {
        edNgay          = (EditText) findViewById(R.id.ed_thu_nhap_ngay);
        edGio           = (EditText) findViewById(R.id.ed_thu_nhap_gio);
        edLoaiThuNhap   = (EditText) findViewById(R.id.ed_thu_nhap_loai_thu_nhap);
        edTongTien      = (EditText) findViewById(R.id.ed_thu_nhap_tong_tien);
        edGhiChu        = (EditText) findViewById(R.id.ed_thu_nhap_ghi_chu);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    private void setNgayVaGio() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm");

        edNgay.setText(simpleDateFormat1.format(calendar.getTime()));
        edGio.setText(simpleDateFormat2.format(calendar.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        if (item.getItemId() == R.id.btn_save) {
            if (edLoaiThuNhap.getText().toString().isEmpty()) {
                edLoaiThuNhap.setError("Bạn chưa chọn thu nhập");
            } else {
                edLoaiThuNhap.setError(null);
            }

            if (edTongTien.getText().toString().trim().isEmpty()) {
                edTongTien.setError("Bạn chưa nhập tổng tiền");
            } else {
                edTongTien.setError(null);
            }

            if (edLoaiThuNhap.getError() == null && edTongTien.getError() == null) {

                // Tiến hành lưu thông tin vào database tại đây
                Ac ac = new Ac("Thu nhập",edNgay.getText().toString().trim(),
                        edGio.getText().toString().trim(),
                        edLoaiThuNhap.getText().toString().trim(),
                        Float.parseFloat(edTongTien.getText().toString().trim()),
                        edGhiChu.getText().toString().trim(), vehicle.getV_id());
                AcAPI api = new AcAPI(ThuNhapActivity.this,ac);
                api.addAc();
            }
        }

        return super.onOptionsItemSelected(item);
    }
}