package cachoatdong;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.driverassistant.NetWorkChangedListener;
import com.example.driverassistant.R;
import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import API.Ac;
import API.AcAPI;
import API.User;
import API.Vehicle;

public class DoNhienLieuActivity extends AppCompatActivity {

    private EditText edNgay;
    private EditText edGio;
    private EditText edCongToMet;
    private EditText edLoaiNhienLieu;
    private EditText edGiaTrenLit;
    private EditText edSoLit;
    private EditText edTongTien;
    private EditText edTramNhienLieu;
    private EditText edGhiChu;
    private TextInputLayout tilCongToMet;
    private User user;
    private Vehicle vehicle;

    private double giaTrenLit = 0;
    private double tongTien = 0;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_do_nhien_lieu);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        
        AnhXa();
        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("User");
        vehicle = (Vehicle) intent.getSerializableExtra("Vehicle");

        setNgayVaGio();

        edNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int ngay = calendar.get(Calendar.DATE);
                int thang = calendar.get(Calendar.MONTH);
                int nam = calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog = new DatePickerDialog(DoNhienLieuActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        calendar.set(year, month, dayOfMonth);
                        edNgay.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, nam, thang, ngay);

                datePickerDialog.show();
            }
        });

        edGio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int gio = calendar.get(Calendar.HOUR_OF_DAY);
                int phut = calendar.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(DoNhienLieuActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
                        calendar.set(0,0,0,hourOfDay,minute);
                        edGio.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, gio, phut, true);

                timePickerDialog.show();
            }
        });

        edLoaiNhienLieu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] listItems = new String[]{"Xăng RON 95-IV", "Xăng RON 92-III", "E5 RON 92-II"
                        , "DO 0,001S-V", "DO 0,05S-II", "Dầu hỏa 2-K"};
                AlertDialog.Builder builder = new AlertDialog.Builder(DoNhienLieuActivity.this);
                builder.setTitle("Chọn nhiên liệu");

                builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        edLoaiNhienLieu.setText(listItems[which]);
                        dialog.dismiss();
                    }
                });
                builder.setCancelable(true);
                AlertDialog dialog = builder.create();

                dialog.show();
            }
        });

        edGiaTrenLit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (edGiaTrenLit.getText().toString().trim().isEmpty()) {
                    giaTrenLit = 0;
                    edSoLit.setText("0");
                } else {
                    giaTrenLit = Double.parseDouble(s.toString());
                    if (giaTrenLit > 0) {
                        edSoLit.setText(String.valueOf(tongTien/giaTrenLit));
                    } else {
                        edSoLit.setText("0");
                    }
                }

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edTongTien.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (edTongTien.getText().toString().trim().isEmpty()) {
                    tongTien = 0;
                    edSoLit.setText("0");
                } else {
                    tongTien = Double.parseDouble(s.toString());
                    if (giaTrenLit == 0) {
                        edSoLit.setText("0");
                    } else {
                        edSoLit.setText(String.valueOf(tongTien/giaTrenLit));
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    private void AnhXa() {
        edNgay              = (EditText) findViewById(R.id.ed_do_nhien_lieu_ngay);
        edGio               = (EditText) findViewById(R.id.ed_do_nhien_lieu_gio);
        edCongToMet         = (EditText) findViewById(R.id.ed_do_nhien_lieu_cong_to_met);
        edLoaiNhienLieu     = (EditText) findViewById(R.id.ed_do_nhien_lieu_loai_nhien_lieu);
        edGiaTrenLit        = (EditText) findViewById(R.id.ed_do_nhien_lieu_gia_tren_lit);
        edSoLit             = (EditText) findViewById(R.id.ed_do_nhien_lieu_so_lit);
        edTongTien          = (EditText) findViewById(R.id.ed_do_nhien_lieu_tong_tien);
        edTramNhienLieu     = (EditText) findViewById(R.id.ed_do_nhien_lieu_tram_nhien_lieu);
        edGhiChu            = (EditText) findViewById(R.id.ed_do_nhien_lieu_ghi_chu);
        tilCongToMet        = (TextInputLayout) findViewById(R.id.til_do_nhien_lieu_cong_to_met);

    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    private void setNgayVaGio() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm");

        edNgay.setText(simpleDateFormat1.format(calendar.getTime()));
        edGio.setText(simpleDateFormat2.format(calendar.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        if (item.getItemId() == R.id.btn_save) {
            if (edCongToMet.getText().toString().trim().isEmpty()) {
                edCongToMet.setError("Bạn chưa nhập công tơ mét");
            } else {
                edCongToMet.setError(null);
            }

            if (edLoaiNhienLieu.getText().toString().isEmpty()) {
                edLoaiNhienLieu.setError("Bạn chưa chọn nhiên liệu");
            } else {
                edLoaiNhienLieu.setError(null);
            }

            if (edGiaTrenLit.getText().toString().trim().isEmpty()) {
                edGiaTrenLit.setError("Bạn chưa nhập giá trên lít");
            } else {
                edGiaTrenLit.setError(null);
            }

            if (edTongTien.getText().toString().trim().isEmpty()) {
                edTongTien.setError("Bạn chưa nhập tổng tiền");
            } else {
                edTongTien.setError(null);
            }

            if (edTramNhienLieu.getText().toString().trim().isEmpty()) {
                edTramNhienLieu.setError("Bạn chưa nhập trạm nhiên liệu");
            } else {
                edTramNhienLieu.setError(null);
            }

            if (edCongToMet.getError() == null && edLoaiNhienLieu.getError() == null
            && edGiaTrenLit.getError() == null && edTongTien.getError() == null) {

                // Tiến hành lưu thông tin vào database tại đây
                Ac ac = new Ac("Đổ nhiên liệu",edNgay.getText().toString().trim(),
                        edGio.getText().toString().trim(),
                        Float.parseFloat(edCongToMet.getText().toString().trim()),
                        edLoaiNhienLieu.getText().toString().trim(),
                        Float.parseFloat(edGiaTrenLit.getText().toString().trim()),
                        Float.parseFloat(edTongTien.getText().toString().trim()),
                        Float.parseFloat(edSoLit.getText().toString().trim()),
                        edTramNhienLieu.getText().toString().trim(),
                        edGhiChu.getText().toString().trim(), vehicle.getV_id());
                AcAPI api = new AcAPI(DoNhienLieuActivity.this,ac);
                api.addAc();
            }
        }

        return super.onOptionsItemSelected(item);
    }
}