package cachoatdong;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.driverassistant.NetWorkChangedListener;
import com.example.driverassistant.R;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import API.Remind;
import API.RemindAPI;
import API.User;
import API.Vehicle;

public class NhacNhoActivity extends AppCompatActivity {

    private EditText edLoaiHoatDong;
    private EditText edNgay;
    private EditText edGhiChu;
    private RadioButton rbChiPhi;
    private RadioButton rbDichVu;
    private User user;
    private Vehicle vehicle;
    private boolean calendarPermissionGranted = false;
    private long ngayDatNhacNho = Calendar.getInstance().getTimeInMillis();
    private long idxoa;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhac_nho);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();
        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("User");
        vehicle = (Vehicle) intent.getSerializableExtra("Vehicle");

        getCalendarPermistion();

        edNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int ngay = calendar.get(Calendar.DATE);
                int thang = calendar.get(Calendar.MONTH);
                int nam = calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog = new DatePickerDialog(NhacNhoActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        calendar.set(year, month, dayOfMonth);
                        edNgay.setText(simpleDateFormat.format(calendar.getTime()).toString());
                        ngayDatNhacNho = calendar.getTimeInMillis();
                    }
                }, nam, thang, ngay);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 2000);

                datePickerDialog.show();
            }
        });

        rbDichVu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edLoaiHoatDong.getText().clear();
                }
            }
        });

        rbChiPhi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edLoaiHoatDong.getText().clear();
                }
            }
        });

        edLoaiHoatDong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] listItems;

                AlertDialog.Builder builder = new AlertDialog.Builder(NhacNhoActivity.this);
                if (rbChiPhi.isChecked()) {
                    listItems = new String[]{"Hoàn trả", "Phí cầu đường", "Rửa xe", "Đóng phạt", "Đăng kiểm"
                            , "Thanh toán", "Tài chính", "Đỗ xe"};
                    builder.setTitle("Chọn chi phí");
                } else {
                    listItems = new String[]{"Mua bảo hiểm", "Đổ xăng", "Thay nhớt", "Bộ lọc nhớt"
                            , "Bộ lọc khí", "Bộ phận đánh lửa", "Cân chỉnh vô lăng", "Hệ thống chuyển hướng"
                            , "Hệ thống ly hợp", "Hệ thống làm mát", "Hệ thống sưởi", "Hệ thống treo"
                            , "Hệ thống ống xả", "Còi xe", "Lớp xe", "Lọc nhiên liệu", "Phanh xe"
                            , "Thắt lưng", "Ghế ngồi", "Yên xe", "Gác chân", "Gương xe", "Kính xe"
                            , "Đèn xe", "Ắc quy", "Công tơ mét"};
                    builder.setTitle("Chọn dịch vụ");
                }

                builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        edLoaiHoatDong.setText(listItems[which]);
                        dialog.dismiss();
                    }
                });
                builder.setCancelable(true);
                AlertDialog dialog = builder.create();

                dialog.show();
            }
        });



    }

    private void AnhXa() {
        edLoaiHoatDong      = (EditText) findViewById(R.id.ed_nhac_nho_loai_hoat_dong);
        edNgay              = (EditText) findViewById(R.id.ed_nhac_nho_ngay);
        edGhiChu            = (EditText) findViewById(R.id.ed_nhac_nho_ghi_chu);
        rbChiPhi            = (RadioButton) findViewById(R.id.rb_nhac_nho_chi_phi);
        rbDichVu            = (RadioButton) findViewById(R.id.rb_nhac_nho_dich_vu);
        rbChiPhi.setChecked(true);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar, menu);

        return super.onCreateOptionsMenu(menu);
    }

    private void getCalendarPermistion() {
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                Manifest.permission.WRITE_CALENDAR)
                == PackageManager.PERMISSION_GRANTED) {
            calendarPermissionGranted = true;
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_CALENDAR}, 2);
        }
    }

    private void setReminderToCalendar() {
        if (calendarPermissionGranted) {
            ContentResolver cr = this.getContentResolver();
            ContentValues cv = new ContentValues();
            cv.put(CalendarContract.Events.TITLE, edLoaiHoatDong.getText().toString());
            cv.put(CalendarContract.Events.DESCRIPTION, edGhiChu.getText().toString());
            cv.put(CalendarContract.Events.DTSTART, ngayDatNhacNho);
            cv.put(CalendarContract.Events.DTEND, ngayDatNhacNho);
            cv.put(CalendarContract.Events.ALL_DAY, 1);
            cv.put(CalendarContract.Events.HAS_ALARM, 1);
            cv.put(CalendarContract.Events.CALENDAR_ID, 1);
            cv.put(CalendarContract.Events.EVENT_TIMEZONE,
                    Calendar.getInstance().getTimeZone().getID());
            Uri uri = cr.insert(CalendarContract.Events.CONTENT_URI, cv);
            long evenID = Long.parseLong(uri.getLastPathSegment());
            idxoa = evenID;
        } else {
            Toast.makeText(NhacNhoActivity.this, "Bạn không thể đặt lịch nhắc nhở"
                    , Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 2) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                calendarPermissionGranted = true;
            }
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        if (item.getItemId() == R.id.btn_save) {
            if (edLoaiHoatDong.getText().toString().isEmpty()) {
                edLoaiHoatDong.setError("Bạn chưa chọn loại hoạt động");
            } else {
                edLoaiHoatDong.setError(null);
            }

            if (edNgay.getText().toString().isEmpty()) {
                edNgay.setError("Bạn chưa chọn ngày nhắc nhở");
            } else {
                edNgay.setError(null);
            }

            if (edLoaiHoatDong.getError() == null && edNgay.getError() == null) {
                setReminderToCalendar();
                // Tiến hành lưu thông tin vào database tại đây
                Remind remind = new Remind(edLoaiHoatDong.getText().toString().trim(),
                        edNgay.getText().toString().trim(),
                        edGhiChu.getText().toString().trim(), vehicle.getV_id(),idxoa);
                RemindAPI api = new RemindAPI(NhacNhoActivity.this,remind);
                api.addRemind();
                finish();
            }
        }

        return super.onOptionsItemSelected(item);
    }
}