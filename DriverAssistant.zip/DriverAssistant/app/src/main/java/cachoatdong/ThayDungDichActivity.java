package cachoatdong;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.driverassistant.NetWorkChangedListener;
import com.example.driverassistant.R;
import com.google.android.material.textfield.TextInputLayout;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import API.Ac;
import API.AcAPI;
import API.User;
import API.Vehicle;

public class ThayDungDichActivity extends AppCompatActivity {

    private EditText edNgay;
    private EditText edGio;
    private EditText edCongToMet;
    private EditText edLoaiDungDich;
    private EditText edTongTien;
    private EditText edCuaHang;
    private EditText edGhiChu;
    private TextInputLayout tilCongToMet;
    private User user;
    private Vehicle vehicle;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thay_dung_dich);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();
        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("User");
        vehicle = (Vehicle) intent.getSerializableExtra("Vehicle");
        setNgayVaGio();

        edNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int ngay = calendar.get(Calendar.DATE);
                int thang = calendar.get(Calendar.MONTH);
                int nam = calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog = new DatePickerDialog(ThayDungDichActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        calendar.set(year, month, dayOfMonth);
                        edNgay.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, nam, thang, ngay);

                datePickerDialog.show();
            }
        });

        edGio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int gio = calendar.get(Calendar.HOUR_OF_DAY);
                int phut = calendar.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(ThayDungDichActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
                        calendar.set(0,0,0,hourOfDay,minute);
                        edGio.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, gio, phut, true);

                timePickerDialog.show();
            }
        });

        edLoaiDungDich.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] listItems = new String[]{"Nhớt", "Nước làm mát", "Dầu phanh"
                        , "Dung dịch ly hợp", "Chất lỏng truyền dẫn"};
                AlertDialog.Builder builder = new AlertDialog.Builder(ThayDungDichActivity.this);
                builder.setTitle("Chọn dung dịch");

                builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        edLoaiDungDich.setText(listItems[which]);
                        dialog.dismiss();
                    }
                });
                builder.setCancelable(true);
                AlertDialog dialog = builder.create();

                dialog.show();
            }
        });

    }

    private void AnhXa() {
        edNgay          = (EditText) findViewById(R.id.ed_thay_dung_dich_ngay);
        edGio           = (EditText) findViewById(R.id.ed_thay_dung_dich_gio);
        edCongToMet     = (EditText) findViewById(R.id.ed_thay_dung_dich_cong_to_met);
        edLoaiDungDich  = (EditText) findViewById(R.id.ed_thay_dung_dich_loai_dung_dich);
        edTongTien      = (EditText) findViewById(R.id.ed_thay_dung_dich_tong_tien);
        edCuaHang       = (EditText) findViewById(R.id.ed_thay_dung_dich_cua_hang);
        edGhiChu        = (EditText) findViewById(R.id.ed_thay_dung_dich_ghi_chu);
        tilCongToMet    = (TextInputLayout) findViewById(R.id.til_thay_dung_dich_cong_to_met);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    private void setNgayVaGio() {
        Calendar calendar = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat1 = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("HH:mm");

        edNgay.setText(simpleDateFormat1.format(calendar.getTime()));
        edGio.setText(simpleDateFormat2.format(calendar.getTime()));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        if(item.getItemId() == R.id.btn_save) {
            if (edCongToMet.getText().toString().trim().isEmpty()) {
                edCongToMet.setError("Bạn chưa nhập công tơ mét");
            } else {
                edCongToMet.setError(null);
            }

            if (edLoaiDungDich.getText().toString().isEmpty()) {
                edLoaiDungDich.setError("Bạn chưa chọn dung dịch");
            } else {
                edLoaiDungDich.setError(null);
            }

            if (edTongTien.getText().toString().trim().isEmpty()) {
                edTongTien.setError("Bạn chưa nhập tổng tiền");
            } else {
                edTongTien.setError(null);
            }

            if (edCuaHang.getText().toString().trim().isEmpty()) {
                edCuaHang.setError("Bạn chưa nhập cửa hàng");
            } else {
                edCuaHang.setError(null);
            }

            if (edCongToMet.getError() == null && edLoaiDungDich.getError() == null
                && edTongTien.getError() == null && edCuaHang.getError() == null) {

                // Tiến hành lưu thông tin vào database tại đây
                Ac ac = new Ac("Thay dung dịch",edNgay.getText().toString().trim(),
                        edGio.getText().toString().trim(),
                        Float.parseFloat(edCongToMet.getText().toString().trim()),
                        edLoaiDungDich.getText().toString().trim(),
                        Float.parseFloat(edTongTien.getText().toString().trim()),
                        edCuaHang.getText().toString().trim(),
                        edGhiChu.getText().toString().trim(), vehicle.getV_id());
                AcAPI api = new AcAPI(ThayDungDichActivity.this,ac);
                api.addAc();
            }
        }

        return super.onOptionsItemSelected(item);
    }
}