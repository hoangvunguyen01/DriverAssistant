package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

import API.User;
import API.UserAPI;

public class CapNhatThongTinTaiKhoanActivity extends AppCompatActivity {

    private EditText edTen;
    private EditText edEmail;
    private EditText edSdt;
    private TextInputLayout tilTen;
    private TextInputLayout tilSdt;
    private Button btnXacNhan;
    private User user;
    private Intent intent;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cap_nhat_thong_tin_tai_khoan);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();

        intent = getIntent();
        user = (User) intent.getSerializableExtra("User");

        edTen.setText(user.getFullname());
        edEmail.setText(user.getEmail());
        edSdt.setText(user.getPhone());

        btnXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edTen.getText().toString().trim().isEmpty()) {
                    tilTen.setError("Bạn chưa nhập tên");
                } else {
                    tilTen.setError(null);
                }

                if (edSdt.getText().toString().trim().isEmpty()) {
                    tilSdt.setError("Bạn chưa nhập số điện thoại");
                } else if (edSdt.getText().toString().trim().length() < 10) {
                    tilSdt.setError("Số điện thoại không hợp lệ");
                } else {
                    tilSdt.setError(null);
                }

                if (tilTen.getError() == null && tilSdt.getError() == null) {
                    //Thực hiện cập nhật thông tin
                    user.setFullname(edTen.getText().toString().trim());
                    user.setEmail(edEmail.getText().toString().trim());
                    user.setPhone(edSdt.getText().toString().trim());
                    UserAPI api = new UserAPI(CapNhatThongTinTaiKhoanActivity.this,user);
                    api.updateUser(intent);
                }
            }
        });
    }

    private void AnhXa() {
        edTen        = (EditText) findViewById(R.id.ed_cap_nhat_thong_tin_ten);
        edEmail      = (EditText) findViewById(R.id.ed_cap_nhat_thong_tin_email);
        edSdt        = (EditText) findViewById(R.id.ed_cap_nhat_thong_tin_sdt);
        tilTen       = (TextInputLayout) findViewById(R.id.til_cap_nhat_thong_tin_ten);
        tilSdt       = (TextInputLayout) findViewById(R.id.til_cap_nhat_thong_tin_sdt);
        btnXacNhan   = (Button) findViewById(R.id.btn_cap_nhat_thong_tin_xac_nhan);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

}