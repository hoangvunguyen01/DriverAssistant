package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import API.Remind;
import API.RemindAPI;
import cachoatdong.NhacNhoActivity;

public class XemNhacNhoActivity extends AppCompatActivity {

    private EditText edLoaiHoatDong;
    private EditText edNgay;
    private EditText edGhiChu;
    private RadioButton rbChiPhi;
    private RadioButton rbDichVu;

    private long ngayDatNhacNho = 0;
    private Remind remind;
    private Intent intent;
    private long idd;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xem_nhac_nho);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();
        intent = getIntent();
        remind = (Remind) intent.getSerializableExtra("Remind");
        String[] tmp = new String[]{"Hoàn trả", "Phí cầu đường", "Rửa xe", "Đóng phạt", "Đăng kiểm"
                , "Thanh toán", "Tài chính", "Đỗ xe"};

        for(int i = 0;i<tmp.length;i++) {
            if(tmp[i].equals(remind.getType())){
                rbChiPhi.setChecked(true);
                break;
            }
        }

        edLoaiHoatDong.setText(remind.getType());
        edNgay.setText(remind.getDate());
        edGhiChu.setText(remind.getNote());


        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Date date = null;
        try {
            date = sdf.parse(remind.getDate());
        } catch (ParseException e) {
            e.printStackTrace();
        }
        ngayDatNhacNho = date.getTime() + 86400000;

        rbDichVu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edLoaiHoatDong.getText().clear();
                }
            }
        });

        rbChiPhi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    edLoaiHoatDong.getText().clear();
                }
            }
        });

        edNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int ngay = calendar.get(Calendar.DATE);
                int thang = calendar.get(Calendar.MONTH);
                int nam = calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog = new DatePickerDialog(XemNhacNhoActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        calendar.set(year, month, dayOfMonth);
                        edNgay.setText(simpleDateFormat.format(calendar.getTime()).toString());
                        ngayDatNhacNho = calendar.getTimeInMillis();
                    }
                }, nam, thang, ngay);
                datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 2000);

                datePickerDialog.show();
            }
        });

        edLoaiHoatDong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] listItems;

                AlertDialog.Builder builder = new AlertDialog.Builder(XemNhacNhoActivity.this);
                if (rbChiPhi.isChecked()) {
                    listItems = new String[]{"Hoàn trả", "Phí cầu đường", "Rửa xe", "Đóng phạt", "Đăng kiểm"
                            , "Thanh toán", "Tài chính", "Đỗ xe"};
                    builder.setTitle("Chọn chi phí");
                } else {
                    listItems = new String[]{"Mua bảo hiểm", "Đổ xăng", "Thay nhớt", "Bộ lọc nhớt"
                            , "Bộ lọc khí", "Bộ phận đánh lửa", "Cân chỉnh vô lăng", "Hệ thống chuyển hướng"
                            , "Hệ thống ly hợp", "Hệ thống làm mát", "Hệ thống sưởi", "Hệ thống treo"
                            , "Hệ thống ống xả", "Còi xe", "Lớp xe", "Lọc nhiên liệu", "Phanh xe"
                            , "Thắt lưng", "Ghế ngồi", "Yên xe", "Gác chân", "Gương xe", "Kính xe"
                            , "Đèn xe", "Ắc quy", "Công tơ mét"};
                    builder.setTitle("Chọn dịch vụ");
                }

                builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        edLoaiHoatDong.setText(listItems[which]);
                        dialog.dismiss();
                    }
                });
                builder.setCancelable(true);
                AlertDialog dialog = builder.create();

                dialog.show();
            }
        });
    }

    private void AnhXa() {
        edLoaiHoatDong = (EditText) findViewById(R.id.ed_xem_nhac_nho_loai_hoat_dong);
        edNgay = (EditText) findViewById(R.id.ed_xem_nhac_nho_ngay);
        edGhiChu = (EditText) findViewById(R.id.ed_xem_nhac_nho_ghi_chu);
        rbChiPhi = (RadioButton) findViewById(R.id.rb_xem_nhac_nho_chi_phi);
        rbDichVu = (RadioButton) findViewById(R.id.rb_xem_nhac_nho_dich_vu);
        rbDichVu.setChecked(true);
        // Nhớ xét loại nhắc nhở thuộc dịch vụ nào để bật radiobutton tương ứng
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_action_bar3, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            intent.putExtra("REMIND",remind);
            setResult(Activity.RESULT_OK,intent);
            finish();
        }

        if (item.getItemId() == R.id.btn_save) {
            if (edLoaiHoatDong.getText().toString().trim().isEmpty()) {
                edLoaiHoatDong.setError("Chưa nhập loại hoạt động");
            } else {
                edLoaiHoatDong.setError(null);
            }

            if (edNgay.getText().toString().trim().isEmpty()) {
                edNgay.setError("Chưa nhập ngày");
            } else {
                edNgay.setError(null);
            }

            if (edLoaiHoatDong.getError() == null && edNgay.getError() == null) {
                XoaCalendar(remind.getC_id());

                ContentResolver cr = this.getContentResolver();
                ContentValues cv = new ContentValues();
                cv.put(CalendarContract.Events.TITLE, edLoaiHoatDong.getText().toString());
                cv.put(CalendarContract.Events.DESCRIPTION, edGhiChu.getText().toString());
                cv.put(CalendarContract.Events.DTSTART, ngayDatNhacNho);
                cv.put(CalendarContract.Events.DTEND, ngayDatNhacNho);
                cv.put(CalendarContract.Events.ALL_DAY, 1);
                cv.put(CalendarContract.Events.HAS_ALARM, 1);
                cv.put(CalendarContract.Events.CALENDAR_ID, 1);
                cv.put(CalendarContract.Events.EVENT_TIMEZONE,
                        Calendar.getInstance().getTimeZone().getID());
                Uri uri = cr.insert(CalendarContract.Events.CONTENT_URI, cv);

                long evenID = Long.parseLong(uri.getLastPathSegment());
                remind.setC_id(evenID);
                remind.setDate(edNgay.getText().toString().trim());
                remind.setType(edLoaiHoatDong.getText().toString().trim());
                remind.setNote(edGhiChu.getText().toString().trim());

                RemindAPI api = new RemindAPI(XemNhacNhoActivity.this,remind);
                api.updateRemind();
                intent.putExtra("REMIND",remind);
                setResult(Activity.RESULT_OK,intent);
                finish();
            }
        }

        if (item.getItemId() == R.id.btn_delete) {
            XoaCalendar(remind.getC_id());
            RemindAPI api = new RemindAPI(XemNhacNhoActivity.this,remind);
            api.deleteRemind();
            setResult(Activity.RESULT_CANCELED);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    private void XoaCalendar(long id) {
        ContentResolver cr = getContentResolver();
        Uri deleteUri = null;
        deleteUri = ContentUris.withAppendedId(CalendarContract.Events.CONTENT_URI, id);
        cr.delete(deleteUri, null, null);
    }
}