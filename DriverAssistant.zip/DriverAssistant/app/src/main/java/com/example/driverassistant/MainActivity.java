package com.example.driverassistant;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.os.Handler;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import API.Ac;
import API.User;
import API.Vehicle;
import chiduong.ChiDuongActivity;
import giaodien.FragmentLichSu;
import giaodien.FragmentNhacNho;
import giaodien.FragmentThemDuLieu;
import timvitri.DichVuGanNhatActivity;

public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener{

    private static final int REQUEST_EMERGENCY_CALL = 113;

    private User user;
    private Vehicle vehicle;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();
    private boolean doubleBackToExitPressedOnce = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        Intent intent = getIntent();
        user = (User) intent.getSerializableExtra("User");
        vehicle = (Vehicle) intent.getSerializableExtra("Vehicle");

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        BottomNavigationView bottomNavigationView =
                (BottomNavigationView) findViewById(R.id.bottom_navigation_view);

        bottomNavigationView.setOnNavigationItemSelectedListener(navListener);

        thayDoiFragMent(new FragmentLichSu());


    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListener =
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.nav_lich_su:
                            thayDoiFragMent(new FragmentLichSu());
                            break;

                        case R.id.nav_them:
                            thayDoiFragMent(new FragmentThemDuLieu());
                            break;

                        case R.id.nav_nhac_nho:
                            thayDoiFragMent(new FragmentNhacNho());
                            break;
                    }
                    return true;
                }
            };

    public void thayDoiFragMent(Fragment data) {
        Fragment fragment = data;
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        Bundle bundle = new Bundle();
        bundle.putSerializable("User",user);
        bundle.putSerializable("Vehicle",vehicle);
        fragment.setArguments(bundle);
        fragmentTransaction.replace(R.id.frame_content, fragment);
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if(drawer.isDrawerOpen((GravityCompat.START))) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (doubleBackToExitPressedOnce) {
                setResult(Activity.RESULT_CANCELED);
                super.onBackPressed();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Nhấn lần nữa để thoát ứng dụng", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce=false;
                }
            }, 2000);
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();
        Intent intent;
        if(id == R.id.nav_thong_tin_tai_khoan){
            intent = new Intent(MainActivity.this, ThongTinTaiKhoanActivity.class);
            intent.putExtra("User",user);
            startActivityForResult(intent,200);
        } else if (id == R.id.nav_doi_mat_khau) {
            intent = new Intent(MainActivity.this, DoiMatKhauActivity.class);
            intent.putExtra("User",user);
            startActivityForResult(intent,201);
        } else if (id == R.id.nav_dich_vu_gan_nhat) {
            intent = new Intent(MainActivity.this, DichVuGanNhatActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_tim_duong) {
            intent = new Intent(MainActivity.this, ChiDuongActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_goi_ho_tro) {
            intent = new Intent(MainActivity.this, GoiDienActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_chon_phuong_tien) {
            intent = new Intent(MainActivity.this, ChonPhuongTienActivity.class);
            intent.putExtra("User",user);
            startActivityForResult(intent, 111);
        } else if (id == R.id.nav_xem_thong_tin_phuong_tien) {
            intent = new Intent(MainActivity.this, XemThongTinPhuongTienActivity.class);
            intent.putExtra("User",user);
            intent.putExtra("Vehicle",vehicle);
            startActivity(intent);
        } else if (id == R.id.nav_dang_xuat) {
            finish();
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 200 && resultCode == Activity.RESULT_OK) {
            user = (User) data.getSerializableExtra("USER");
        }
        else if(requestCode == 201 && resultCode == Activity.RESULT_OK) {
            user = (User) data.getSerializableExtra("USER");
        }
        else if (requestCode == 111 && resultCode == Activity.RESULT_OK) {
            vehicle = (Vehicle) data.getSerializableExtra("VEHICLE");
            user = (User) data.getSerializableExtra("USER");
            thayDoiFragMent(new FragmentLichSu());
        }
    }
}