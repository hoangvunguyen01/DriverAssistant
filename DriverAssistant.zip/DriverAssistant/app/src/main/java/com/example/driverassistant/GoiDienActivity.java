package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.inputmethod.EditorInfo;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import API.RequestHandler;
import API.URL;
import API.Vehicle;
import adaptor.GoiDienAdapter;
import adaptor.TinhThanh;

public class GoiDienActivity extends AppCompatActivity {

    private static final int REQUEST_CALL = 111;

    private RecyclerView rvTinhThanh;
    private GoiDienAdapter adapter;
    private List<TinhThanh> tinhThanhList = new ArrayList<>();
    private List<TinhThanh> tinhThanhListFull = new ArrayList<>();
    private String sdt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goi_dien);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getTinhThanh();

        rvTinhThanh = (RecyclerView) findViewById(R.id.rv_tinh_thanh);
        rvTinhThanh.setHasFixedSize(true);
        rvTinhThanh.setLayoutManager(new LinearLayoutManager(GoiDienActivity.this,
                LinearLayoutManager.VERTICAL, false));

        rvTinhThanh.addItemDecoration(new DividerItemDecoration(rvTinhThanh.getContext()
                , DividerItemDecoration.VERTICAL));

        adapter = new GoiDienAdapter(tinhThanhList,tinhThanhListFull, GoiDienActivity.this);


        rvTinhThanh.setAdapter(adapter);
    }

    private void getTinhThanh() {
        StringRequest postRequest = new StringRequest(Request.Method.GET, URL.GET_PHONE_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                JSONArray result = jsonObject.getJSONArray("result");
                                for(int i = 0;i<result.length();i++) {
                                    JSONObject data = result.getJSONObject(i);
                                    TinhThanh tt = new TinhThanh(data.getString("name"),
                                            data.getString("phone"));
                                    tinhThanhList.add(tt);
                                }
                                tinhThanhListFull.addAll(tinhThanhList);
                                adapter.notifyDataSetChanged();
                            } else {
                                Toast.makeText(getBaseContext(), "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getBaseContext(), "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        );
        RequestHandler.getInstance(getBaseContext()).addToRequestQueue(postRequest);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.goi_dien_menu, menu);

        MenuItem item = menu.findItem(R.id.action_search);
        SearchView searchView = (SearchView) item.getActionView();

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });


        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void makePhoneCall(String number) {
        this.sdt = number;
        if (ContextCompat.checkSelfPermission(GoiDienActivity.this,
                Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(GoiDienActivity.this,
                    new String[] {Manifest.permission.CALL_PHONE}, REQUEST_CALL);
        } else {
            String dial = "tel:" + sdt;
            startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall(sdt);
            } else {
                Toast.makeText(GoiDienActivity.this, "Không thể thực hiện cuộc gọi",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }
}