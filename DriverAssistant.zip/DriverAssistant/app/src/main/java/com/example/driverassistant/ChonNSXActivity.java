package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;

import java.util.ArrayList;
import java.util.List;

import adaptor.ChonNSXAdapter;
import adaptor.NSX;

public class ChonNSXActivity extends AppCompatActivity {

    private RecyclerView rvNsx;
    private List<NSX> nsxList = new ArrayList<>();
    private ChonNSXAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chon_n_s_x);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        getNsx();

        rvNsx = (RecyclerView) findViewById(R.id.rv_chon_nsx);
        rvNsx.setHasFixedSize(true);
        rvNsx.setLayoutManager(new LinearLayoutManager(ChonNSXActivity.this,
                LinearLayoutManager.VERTICAL, false));
        rvNsx.addItemDecoration(new DividerItemDecoration(rvNsx.getContext()
                , DividerItemDecoration.VERTICAL));

        adapter = new ChonNSXAdapter(nsxList, ChonNSXActivity.this);

        rvNsx.setAdapter(adapter);
    }

    private void getNsx() {
        nsxList.add(new NSX("Honda", R.drawable.ic_honda_moto));
        nsxList.add(new NSX("Suzuki", R.drawable.ic_suzuki));
        nsxList.add(new NSX("Sym", R.drawable.ic_sym));
        nsxList.add(new NSX("VinFast", R.drawable.ic_vinfast));
        nsxList.add(new NSX("Yamaha", R.drawable.ic_yamaha));
        nsxList.add(new NSX("Chevrolet", R.drawable.ic_chevrolet));
        nsxList.add(new NSX("Ford", R.drawable.ic_ford));
        nsxList.add(new NSX("Honda", R.drawable.ic_honda_oto));
        nsxList.add(new NSX("Huyndai", R.drawable.ic_huyndai));
        nsxList.add(new NSX("Kia", R.drawable.ic_kia));
        nsxList.add(new NSX("Toyota", R.drawable.ic_toyota));
        nsxList.add(new NSX("Foton", R.drawable.ic_foton));
        nsxList.add(new NSX("Hino", R.drawable.ic_hino));
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void traVeNSX(NSX nsx) {
        Intent intent = getIntent();
        intent.putExtra("TEN_NSX", nsx.getTenNsx());
        intent.putExtra("ICON", nsx.getIcon());

        setResult(Activity.RESULT_OK, intent);

        finish();
    }

}