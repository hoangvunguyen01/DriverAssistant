package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.material.textfield.TextInputLayout;

import API.User;
import API.Vehicle;
import API.VehicleAPI;

public class TaoPhuongTienActivity extends AppCompatActivity {

    private static final int REQUEST_CHON_NSX = 134;

    private EditText edLoaiXe;
    private EditText edTenXe;
    private EditText edNsx;
    private EditText edBienSo;
    private EditText edDungTich;
    private ImageView imgLoaiXe;
    private ImageView imgNsx;

    private TextInputLayout tilTenXe;
    private TextInputLayout tilNsx;
    private TextInputLayout tilBienSo;
    private TextInputLayout tilDungTich;

    private User user;
    private Vehicle vehicle;
    private Intent intent0;
    private int icon;
    private boolean screenDK;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tao_phuong_tien);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();

        intent0 = getIntent();
        screenDK = intent0.getBooleanExtra("DK",false);
        if(screenDK) {
            user = (User) intent0.getSerializableExtra("User");
        }
        else {
            user = (User) intent0.getSerializableExtra("UseR");
        }

        edLoaiXe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String[] listItems = new String[]{"Xe máy", "Xe hơi", "Xe tải"};
                AlertDialog.Builder builder = new AlertDialog.Builder(TaoPhuongTienActivity.this);
                builder.setTitle("Chọn chi phí");

                builder.setSingleChoiceItems(listItems, -1, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if (which == 0) {
                            imgLoaiXe.setImageResource(R.drawable.ic_moto);
                        } else if (which == 1) {
                            imgLoaiXe.setImageResource(R.drawable.ic_oto);
                        } else {
                            imgLoaiXe.setImageResource(R.drawable.ic_truck);
                        }
                        edLoaiXe.setText(listItems[which]);
                        dialog.dismiss();
                    }
                });
                builder.setCancelable(true);
                AlertDialog dialog = builder.create();

                dialog.show();
            }
        });

        edNsx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(TaoPhuongTienActivity.this,
                        ChonNSXActivity.class);

                startActivityForResult(intent1, REQUEST_CHON_NSX);
            }
        });

    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    private void AnhXa() {
        edLoaiXe    = (EditText) findViewById(R.id.ed_tao_pt_loai_xe);
        edTenXe     = (EditText) findViewById(R.id.ed_tao_pt_ten_xe);
        edNsx       = (EditText) findViewById(R.id.ed_tao_pt_nsx);
        edBienSo    = (EditText) findViewById(R.id.ed_tao_pt_bien_so);
        edDungTich  = (EditText) findViewById(R.id.ed_tao_pt_dung_tich);
        imgLoaiXe   = (ImageView) findViewById(R.id.img_tao_pt_loai_xe);
        imgNsx      = (ImageView) findViewById(R.id.img_tao_pt_nsx);

        tilTenXe    = (TextInputLayout) findViewById(R.id.til_tao_pt_ten);
        tilNsx      = (TextInputLayout) findViewById(R.id.til_tao_pt_nsx);
        tilBienSo   = (TextInputLayout) findViewById(R.id.til_tao_pt_bien_so);
        tilDungTich = (TextInputLayout) findViewById(R.id.til_tao_pt_dung_tich);

        imgNsx.setImageResource(R.drawable.icon_question);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CHON_NSX && resultCode == Activity.RESULT_OK) {
            String tenNsx = data.getStringExtra("TEN_NSX");
            icon = data.getIntExtra("ICON", R.drawable.icon_question);
            edNsx.setText(tenNsx);
            imgNsx.setImageResource(icon);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        if (item.getItemId() == R.id.btn_save) {
            // Lưu thông tin thiết bị
            if (edTenXe.getText().toString().trim().isEmpty()) {
                tilTenXe.setError("Bạn chưa nhập tên xe");
            } else {
                tilTenXe.setError(null);
            }

            if (edNsx.getText().toString().isEmpty()) {
                tilNsx.setError("Bạn chưa chọn nhà sản xuất");
            } else {
                tilNsx.setError(null);
            }

            if (edBienSo.getText().toString().trim().isEmpty()) {
                tilBienSo.setError("Bạn chưa nhập biển số");
            } else {
                tilBienSo.setError(null);
            }

            if (edDungTich.getText().toString().trim().isEmpty()) {
                tilDungTich.setError("Bạn chưa nhập dung tích");
            } else {
                tilDungTich.setError(null);
            }

            if (tilNsx.getError() == null && tilTenXe.getError() == null
            && tilBienSo.getError() == null && tilDungTich.getError() == null) {
                //Cập nhật vào database
                    vehicle = new Vehicle(edBienSo.getText().toString().trim(),
                            edLoaiXe.getText().toString().trim(),
                            edTenXe.getText().toString().trim(),
                            edNsx.getText().toString().trim(),
                            icon, Float.parseFloat(edDungTich.getText().toString().trim()),
                            user.getUsername());
                    VehicleAPI api = new VehicleAPI(TaoPhuongTienActivity.this,
                            MainActivity.class, vehicle);
                    api.addVehicle(screenDK, user);
            }
        }

        return super.onOptionsItemSelected(item);
    }
}