package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.textfield.TextInputLayout;

import API.User;
import API.UserAPI;

public class DangKyActivity extends AppCompatActivity {

    private EditText edTen;
    private EditText edTaiKhoan;
    private EditText edMatKhau;
    private EditText edXacNhanMatKhau;
    private EditText edEmail;
    private EditText edSdt;
    private Button btnXacNhan;

    private TextInputLayout tilTen;
    private TextInputLayout tilTaiKhoan;
    private TextInputLayout tilMatKhau;
    private TextInputLayout tilXacNhanMatKhau;
    private TextInputLayout tilEmail;
    private TextInputLayout tilSdt;

    private User user;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_ky);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();

        btnXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edTen.getText().toString().trim().isEmpty()) {
                    tilTen.setError("Bạn chưa nhập họ tên");
                } else {
                    tilTen.setError(null);
                }

                if (edTaiKhoan.getText().toString().trim().isEmpty()) {
                    tilTaiKhoan.setError("Bạn chưa nhập tại khoản");
                }  else if (!checkKhoangTrang(edTaiKhoan.getText().toString())) {
                    tilTaiKhoan.setError("Tài khoản không được chứa khoảng trắng");
                } else if (!checkInHoa(edTaiKhoan.getText().toString())) {
                    tilTaiKhoan.setError("Tài khoản không được in hoa");
                } else {
                    tilTaiKhoan.setError(null);
                }

                if (edMatKhau.getText().toString().trim().isEmpty()) {
                    tilMatKhau.setError("Bạn chưa nhập mật khẩu");
                } else {
                    tilMatKhau.setError(null);
                }

                if (edXacNhanMatKhau.getText().toString().trim().isEmpty()) {
                    tilXacNhanMatKhau.setError("Bạn phải xác nhận mật khẩu");
                } else if (!edXacNhanMatKhau.getText().toString().trim()
                        .equals(edMatKhau.getText().toString().trim())) {
                    tilXacNhanMatKhau.setError("Mật khẩu xác nhận không đúng");
                } else {
                    tilXacNhanMatKhau.setError(null);
                }

                if (edEmail.getText().toString().trim().isEmpty()) {
                    tilEmail.setError("Bạn chưa nhập Email");
                } else {
                    tilEmail.setError(null);
                }

                if (edSdt.getText().toString().trim().isEmpty()) {
                    tilSdt.setError("Bạn chưa nhập số điện thoại");
                } else if (edSdt.getText().toString().trim().length() < 10){
                    tilSdt.setError("Số điện thoại không hợp lệ");
                } else {
                    tilSdt.setError(null);
                }

                if (tilTen.getError() == null && tilTaiKhoan.getError() == null
                && tilMatKhau.getError() == null && tilXacNhanMatKhau.getError() == null
                && tilEmail.getError() == null && tilSdt.getError() == null) {
                    user = new User(edTaiKhoan.getText().toString().trim(),
                            edMatKhau.getText().toString().trim(),
                            edTen.getText().toString().trim(),
                            edEmail.getText().toString().trim(),
                            edSdt.getText().toString().trim());
                    UserAPI api = new UserAPI(DangKyActivity.this,TaoPhuongTienActivity.class,user);
                    api.addUser();
                }
            }
        });
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    private void AnhXa() {
        edTen             = (EditText) findViewById(R.id.ed_dang_ky_ten);
        edTaiKhoan        = (EditText) findViewById(R.id.ed_dang_ky_tai_khoan);
        edMatKhau         = (EditText) findViewById(R.id.ed_dang_ky_mat_khau);
        edXacNhanMatKhau  = (EditText) findViewById(R.id.ed_dang_ky_xac_nhan_mat_khau);
        edEmail           = (EditText) findViewById(R.id.ed_dang_ky_email);
        edSdt             = (EditText) findViewById(R.id.ed_dang_ky_sdt);
        btnXacNhan        = (Button) findViewById(R.id.btn_dang_ky_xac_nhan);

        tilTen            = (TextInputLayout) findViewById(R.id.til_dang_ky_ten);
        tilTaiKhoan       = (TextInputLayout) findViewById(R.id.til_dang_ky_tai_khoan);
        tilMatKhau        = (TextInputLayout) findViewById(R.id.til_dang_ky_mat_khau);
        tilXacNhanMatKhau = (TextInputLayout) findViewById(R.id.til_dang_ky_xac_nhan_mat_khau);
        tilEmail          = (TextInputLayout) findViewById(R.id.til_dang_ky_email);
        tilSdt            = (TextInputLayout) findViewById(R.id.til_dang_ky_sdt);
    }

    private boolean checkKhoangTrang(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (Character.isWhitespace(str.charAt(i))) {
                return false;
            }
            i++;
        }
        return true;
    }

    private boolean checkInHoa(String str) {
        for (int i = 0; i < str.length(); i++) {
            if (Character.isUpperCase(str.charAt(i))) {
                return false;
            }
            i++;
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}