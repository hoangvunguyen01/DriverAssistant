package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import API.Vehicle;
import API.VehicleAPI;
import cachoatdong.ChiPhiActivity;

public class ThongTinChiTietPhuongTienActivity extends AppCompatActivity {

    private EditText edLoaiXe;
    private EditText edTen;
    private EditText edNsx;
    private EditText edBienSo;
    private EditText edDungTich;
    private ImageView imgNsx;
    private ImageView imgLoaiXe;
    private Vehicle vehicle;
    private Intent intent;
    private Boolean xd;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin_chi_tiet_phuong_tien);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();
        intent = getIntent();
        vehicle = (Vehicle) intent.getSerializableExtra("Vehicle");
        xd = intent.getBooleanExtra("XD",false);
        edTen.setText(vehicle.getV_name());
        edLoaiXe.setText(vehicle.getType());
        edBienSo.setText(vehicle.getV_id());
        imgNsx.setImageResource(vehicle.getIcon());
        if(vehicle.getType().equals("Xe máy")) {
            imgLoaiXe.setImageResource(R.drawable.ic_moto);
        } else if(vehicle.getType().equals("Xe hơi")) {
            imgLoaiXe.setImageResource(R.drawable.ic_oto);
        } else if(vehicle.getType().equals("Xe tải")) {
            imgLoaiXe.setImageResource(R.drawable.ic_truck);
        }
        edDungTich.setText(String.valueOf(vehicle.getCapacity()));
        edNsx.setText(vehicle.getProducer());
    }

    private void AnhXa() {
        edLoaiXe     = (EditText) findViewById(R.id.ed_chi_tiet_pt_loai_xe);
        edTen        = (EditText) findViewById(R.id.ed_chi_tiet_pt_ten_xe);
        edNsx        = (EditText) findViewById(R.id.ed_chi_tiet_pt_nsx);
        edBienSo     = (EditText) findViewById(R.id.ed_chi_tiet_pt_bien_so);
        edDungTich   = (EditText) findViewById(R.id.ed_chi_tiet_pt_dung_tich);
        imgNsx       = (ImageView) findViewById(R.id.img_chi_tiet_pt_nsx);
        imgLoaiXe    = (ImageView) findViewById(R.id.img_chi_tiet_pt_loai_xe);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar3, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            intent.putExtra("VEHICLE",vehicle);
            setResult(Activity.RESULT_OK,intent);
            finish();
        }

        if (item.getItemId() == R.id.btn_save) {
            if (edTen.getText().toString().trim().isEmpty()) {
                edTen.setError("Bạn chưa nhập tên phương tiện");
            } else {
                edTen.setError(null);
            }

            if (edDungTich.getText().toString().trim().isEmpty()) {
                edDungTich.setError("Bạn chưa nhập dung tích");
            } else {
                edDungTich.setError(null);
            }

            if (edTen.getError() == null && edDungTich.getError() == null) {
                // Cập nhật phương tiện
                if(xd) {
                    Toast.makeText(ThongTinChiTietPhuongTienActivity.this,
                            "Bạn đang chọn phương tiện hiển thị không thể cập nhật!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    vehicle.setV_name(edTen.getText().toString().trim());
                    vehicle.setCapacity(Float.parseFloat(edDungTich.getText().toString().trim()));

                    VehicleAPI api = new VehicleAPI(ThongTinChiTietPhuongTienActivity.this, vehicle);
                    api.updateVehicle();
                    intent.putExtra("VEHICLE",vehicle);
                    setResult(Activity.RESULT_OK,intent);
                    finish();
                }
            }
        }

        if (item.getItemId() == R.id.btn_delete) {
            if(xd) {
                Toast.makeText(ThongTinChiTietPhuongTienActivity.this,
                        "Bạn đang chọn phương tiện hiển thị không thể xóa!",
                        Toast.LENGTH_SHORT).show();
            } else {
                // Xóa phương tiện
                AlertDialog.Builder builder =
                        new AlertDialog.Builder(ThongTinChiTietPhuongTienActivity.this);

                builder.setTitle("Xác nhận xóa")
                        .setMessage("Bạn có có thật sự muốn xóa phương tiện này không ?");

                builder.setPositiveButton("Có", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Xóa phương tiện
                        VehicleAPI api = new VehicleAPI(ThongTinChiTietPhuongTienActivity.this, vehicle);
                        api.deleteVehicle();
                        setResult(Activity.RESULT_CANCELED);
                        finish();
                    }
                });

                builder.setNegativeButton("Không", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        }
        return super.onOptionsItemSelected(item);
    }

    private void showDeleteConfirmDialog() {

    }

}