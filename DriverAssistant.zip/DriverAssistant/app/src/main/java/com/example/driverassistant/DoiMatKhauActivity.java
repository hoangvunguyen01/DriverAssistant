package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.google.android.material.textfield.TextInputLayout;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import API.RequestHandler;
import API.URL;
import API.User;
import API.UserAPI;

public class DoiMatKhauActivity extends AppCompatActivity {

    private EditText edMkCu;
    private EditText edMkMoi;
    private EditText edXacNhanMkMoi;
    private TextInputLayout tilMkCu;
    private TextInputLayout tilMkMoi;
    private TextInputLayout tilXacNhanMkMoi;
    private Button btnXacNhan;
    private Intent intent;
    private User user;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doi_mat_khau);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();

        intent = getIntent();
        user = (User) intent.getSerializableExtra("User");

        btnXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edMkCu.getText().toString().trim().isEmpty()) {
                    tilMkCu.setError("Bạn chưa nhập mật khẩu cũ");
                } else if (edMkMoi.getText().toString().trim().isEmpty()) {
                    tilMkCu.setError(null);
                    tilMkMoi.setError("Bạn chưa nhập mật khẩu mới");
                } else if (edXacNhanMkMoi.getText().toString().trim().isEmpty()) {
                    tilMkMoi.setError(null);
                    tilXacNhanMkMoi.setError("Bạn chưa xác nhận mật khẩu mới");
                } else if (!edMkMoi.getText().toString().trim()
                        .equals(edXacNhanMkMoi.getText().toString().trim())) {
                    tilXacNhanMkMoi.setError("Mật khẩu xác nhận không trùng khớp");
                } else if (!edMkCu.getText().toString().trim().equals(user.getPassword())){
                    tilMkCu.setError("Mật khẩu không trùng khớp");
                } else {
                    // Đổi mật khẩu
                    user.setPassword(edMkMoi.getText().toString().trim());
                    UserAPI api = new UserAPI(DoiMatKhauActivity.this,user);
                    api.updateUser(intent);
                }

            }
        });
    }

    private void AnhXa() {
        edMkCu = (EditText) findViewById(R.id.ed_doi_mk_mk_cu);
        edMkMoi = (EditText) findViewById(R.id.ed_doi_mk_mk_moi);
        edXacNhanMkMoi = (EditText) findViewById(R.id.ed_doi_mk_xac_nhan_mk_moi);
        tilMkCu = (TextInputLayout) findViewById(R.id.til_doi_mk_mk_cu);
        tilMkMoi = (TextInputLayout) findViewById(R.id.til_doi_mk_mk_moi);
        tilXacNhanMkMoi = (TextInputLayout) findViewById(R.id.til_doi_mk_xac_nhan_mk_moi);
        btnXacNhan = (Button) findViewById(R.id.btn_doi_mk_xac_nhan);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}