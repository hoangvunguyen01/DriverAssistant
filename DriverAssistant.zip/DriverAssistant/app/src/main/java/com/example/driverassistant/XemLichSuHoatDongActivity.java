package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import API.Ac;
import API.AcAPI;
import cachoatdong.ChiPhiActivity;
import cachoatdong.DoNhienLieuActivity;

public class XemLichSuHoatDongActivity extends AppCompatActivity {

    private static final int REQUEST_CHINH_SUA_HOAT_DONG = 177;

    private EditText edTenHd;
    private EditText edTypeHd;
    private EditText edNgay;
    private EditText edGio;
    private EditText edTongTien;
    private EditText edCongToMet;
    private Ac ac;
    private Intent intent;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xem_lich_su_hoat_dong);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();
        // Tùy vào loại hoạt động mà ẩn đi cái edCongToMet
        intent = getIntent();
        ac = (Ac) intent.getSerializableExtra("Ac");
        if (ac.getName().equals("Đổ nhiên liệu")) {
            edCongToMet.setText(String.valueOf(ac.getOdometer()));
        } else if (ac.getName().equals("Thay dung dịch")) {
            edCongToMet.setText(String.valueOf(ac.getOdometer()));
        } else if (ac.getName().equals("Thu nhập")) {
            edCongToMet.setVisibility(View.GONE);
        } else if (ac.getName().equals("Chi phí")) {
            edCongToMet.setVisibility(View.GONE);
        } else if (ac.getName().equals("Sửa chữa")) {
            edCongToMet.setText(String.valueOf(ac.getOdometer()));
        }

        edTenHd.setText(ac.getName());
        edTypeHd.setText(ac.getType());
        edNgay.setText(ac.getDate());
        edGio.setText(ac.getTime());
        edTongTien.setText(String.valueOf(ac.getMoney()));

        edNgay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int ngay = calendar.get(Calendar.DATE);
                int thang = calendar.get(Calendar.MONTH);
                int nam = calendar.get(Calendar.YEAR);

                DatePickerDialog datePickerDialog = new DatePickerDialog(XemLichSuHoatDongActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
                        calendar.set(year, month, dayOfMonth);
                        edNgay.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, nam, thang, ngay);

                datePickerDialog.show();
            }
        });

        edGio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Calendar calendar = Calendar.getInstance();
                int gio = calendar.get(Calendar.HOUR_OF_DAY);
                int phut = calendar.get(Calendar.MINUTE);

                TimePickerDialog timePickerDialog = new TimePickerDialog(XemLichSuHoatDongActivity.this,
                        new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("HH:mm");
                        calendar.set(0,0,0,hourOfDay,minute);
                        edGio.setText(simpleDateFormat.format(calendar.getTime()).toString());
                    }
                }, gio, phut, true);

                timePickerDialog.show();
            }
        });
    }

    private void AnhXa() {
        edTenHd         = (EditText) findViewById(R.id.ed_xem_ls_hd_ten);
        edTypeHd        = (EditText) findViewById(R.id.ed_xem_ls_hd_type);
        edNgay          = (EditText) findViewById(R.id.ed_xem_ls_hd_ngay);
        edGio           = (EditText) findViewById(R.id.ed_xem_ls_hd_gio);
        edTongTien      = (EditText) findViewById(R.id.ed_xem_ls_hd_tong_tien);
        edCongToMet     = (EditText) findViewById(R.id.ed_xem_ls_hd_cong_to_met);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar3, menu);

        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            intent.putExtra("AC",ac);
            setResult(Activity.RESULT_OK,intent);
            finish();
        }

        if (item.getItemId() == R.id.btn_save) {

            if (edTongTien.getText().toString().trim().isEmpty()) {
                edTongTien.setError("Chưa nhập tổng tiền");
            } else {
                edTongTien.setError(null);
            }

            // Nhớ thêm 1 đk là hoạt động có bao gồm công tơ mét
            if (edCongToMet.getText().toString().trim().isEmpty()) {
                edCongToMet.setError("Chưa nhập công tơ mét");
            } else {
                edCongToMet.setError(null);
            }

            if (edTongTien.getError() == null && edCongToMet.getError() == null) {
                //Tiến hành save hoạt động lại
                ac.setDate(edNgay.getText().toString().trim());
                ac.setTime(edGio.getText().toString().trim());
                ac.setMoney(Float.parseFloat(edTongTien.getText().toString().trim()));
                ac.setOdometer(Float.parseFloat(edCongToMet.getText().toString().trim()));
                AcAPI api = new AcAPI(XemLichSuHoatDongActivity.this,ac);
                api.updateAc();
                intent.putExtra("AC",ac);
                setResult(Activity.RESULT_OK,intent);
                finish();
            }
        }

        if (item.getItemId() == R.id.btn_delete) {
            // Xóa hoạt động khỏi database
            AcAPI api = new AcAPI(XemLichSuHoatDongActivity.this,ac);
            api.deleteAc();
            setResult(Activity.RESULT_CANCELED);
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

}