package com.example.driverassistant;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class CheckConnection {
    public static boolean isConnectedToInternet(Context context) {

        ConnectivityManager manager = (ConnectivityManager)
                context.getSystemService(context.CONNECTIVITY_SERVICE);

        // Kiểm tra coi có cho kết nối internet không
        if (manager != null) {
            NetworkInfo[] infos = manager.getAllNetworkInfo();
            // kt tất cả các loại network coi có cái nào conect chưa
            if (infos != null) {
                for (NetworkInfo info: infos) {
                    if (info.getState() == NetworkInfo.State.CONNECTED) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
