package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import API.User;

public class ThongTinTaiKhoanActivity extends AppCompatActivity {

    private TextView tvTen;
    private TextView tvEmail;
    private TextView tvSdt;

    private User user;
    Intent intent;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thong_tin_tai_khoan);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();

        intent = getIntent();
        user = (User) intent.getSerializableExtra("User");

        tvTen.setText(user.getFullname());
        tvEmail.setText(user.getEmail());
        tvSdt.setText(user.getPhone());
    }

    private void AnhXa() {
        tvTen    = (TextView) findViewById(R.id.tv_thong_tin_tk_ten);
        tvEmail  = (TextView) findViewById(R.id.tv_thong_tin_tk_email);
        tvSdt    = (TextView) findViewById(R.id.tv_thong_tin_tk_sdt);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar1, menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            intent.putExtra("USER",user);
            setResult(Activity.RESULT_OK,intent);
            finish();
        }

        if (item.getItemId() == R.id.btn_edit) {
            Intent intent1 = new Intent(this, CapNhatThongTinTaiKhoanActivity.class);
            intent1.putExtra("User",user);
            startActivityForResult(intent1,101);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 101 && resultCode == Activity.RESULT_FIRST_USER) {
            user = (User) data.getSerializableExtra("USER");
            tvTen.setText(user.getFullname());
            tvEmail.setText(user.getEmail());
            tvSdt.setText(user.getPhone());
        }
    }
}