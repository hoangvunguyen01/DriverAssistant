package com.example.driverassistant;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import API.RequestHandler;
import API.URL;
import API.User;
import API.Vehicle;
import adaptor.ChonPhuongTienAdapter;
import adaptor.VehicleAdapter;

public class ChonPhuongTienActivity extends AppCompatActivity {

    private static final int REQUEST_THEM_PHUONG_TIEN = 333;
    private User user;
    private List<Vehicle> vehicleList;
    private ChonPhuongTienAdapter vehicleAdapter;
    private RecyclerView recyclerView;
    private Intent intent;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_danh_sach_phuong_tien);

        recyclerView = findViewById(R.id.rv_danh_sach_phuong_tien_danh_sach);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        intent = getIntent();
        user = (User) intent.getSerializableExtra("User");

        vehicleList = new ArrayList<>();
        vehicleAdapter = new ChonPhuongTienAdapter(vehicleList, ChonPhuongTienActivity.this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,
                LinearLayoutManager.VERTICAL, false));
        recyclerView.addItemDecoration(new DividerItemDecoration(this,
                DividerItemDecoration.VERTICAL));
        recyclerView.setAdapter(vehicleAdapter);

        getVehicles(user.getUsername());
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }


        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    public void getVehicles(String user) {
        vehicleList.clear();
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.GET_VEHICLE_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                JSONArray result = jsonObject.getJSONArray("result");
                                for(int i = 0;i<result.length();i++) {
                                    JSONObject data = result.getJSONObject(i);
                                    Vehicle v = new Vehicle(data.getString("v_id"),
                                            data.getString("type"),
                                            data.getString("v_name"),
                                            data.getString("producer"),
                                            data.getInt("icon"),
                                            Float.parseFloat(data.getString("capacity")),
                                            data.getString("username"));
                                    vehicleList.add(v);
                                }
                                vehicleAdapter.notifyDataSetChanged();
                            } else {
                                Toast.makeText(getBaseContext(), "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getBaseContext(), "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", user);
                return params;
            }
        };
        RequestHandler.getInstance(getBaseContext()).addToRequestQueue(postRequest);
    }

    public void finishChonActivity(Vehicle vehicle1) {
        Intent intent1 = new Intent();
        intent1.putExtra("VEHICLE",vehicle1);
        intent1.putExtra("USER",user);
        setResult(Activity.RESULT_OK,intent1);
        finish();
    }
}
