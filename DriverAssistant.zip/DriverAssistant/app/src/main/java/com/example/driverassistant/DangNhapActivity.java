package com.example.driverassistant;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.textfield.TextInputLayout;

import API.User;
import API.UserAPI;
import API.Vehicle;


    public class DangNhapActivity extends AppCompatActivity {

    private EditText edTaikhoan;
    private TextInputLayout tilTaikhoan;
    private EditText edMatKhau;
    private TextInputLayout tilMatKhau;
    private Button btnXacNhan;
    private Button btnDangKy;
    private CheckBox cbGhiNhoTaiKhoan;
    private SharedPreferences sharedPreferences;
    private Vehicle vehicle;
    private User user;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dang_nhap);

        AnhXa();

        sharedPreferences = getSharedPreferences("datalogin", MODE_PRIVATE);
        edTaikhoan.setText(sharedPreferences.getString("taikhoan", ""));
        edMatKhau.setText(sharedPreferences.getString("matkhau", ""));
        cbGhiNhoTaiKhoan.setChecked(sharedPreferences.getBoolean("checked", false));

        if (!edTaikhoan.getText().toString().isEmpty()) {
            String tk = edTaikhoan.getText().toString().trim();
            String mk = edMatKhau.getText().toString().trim();
            UserAPI api = new UserAPI(DangNhapActivity.this,ChonPhuongTienActivity.class);
            api.checkUser(tk,mk);
        }

        btnDangKy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(DangNhapActivity.this, DangKyActivity.class);

                startActivity(intent);
            }
        });

        btnXacNhan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String tk = edTaikhoan.getText().toString().trim();
                String mk = edMatKhau.getText().toString().trim();
                if(checkDangnhap(tk,mk)) {
                    //checkUser(tk,mk);
                    UserAPI api = new UserAPI(DangNhapActivity.this,ChonPhuongTienActivity.class);
                    api.checkUser(tk,mk);
                }
            }
        });

    }

    private void AnhXa() {
        edTaikhoan = (EditText) findViewById(R.id.ed_tai_khoan);
        tilTaikhoan = (TextInputLayout) findViewById(R.id.til_tai_khoan);
        edMatKhau = (EditText) findViewById(R.id.ed_mat_khau);
        tilMatKhau = (TextInputLayout) findViewById(R.id.til_mat_khau);
        btnXacNhan = (Button) findViewById(R.id.btn_dang_nhap);
        btnDangKy = (Button) findViewById(R.id.btn_dang_ky);
        cbGhiNhoTaiKhoan = (CheckBox) findViewById(R.id.cb_ghi_nho_tai_khoan);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 100 && resultCode == Activity.RESULT_OK) {
            SharedPreferences.Editor editor = sharedPreferences.edit();
            if (cbGhiNhoTaiKhoan.isChecked()) {
                editor.putString("taikhoan", edTaikhoan.getText().toString());
                editor.putString("matkhau", edMatKhau.getText().toString());
                editor.putBoolean("checked", true);
            } else {
                editor.remove("taikhoan");
                editor.remove("matkhau");
                editor.remove("checked");
            }

            editor.commit();

            edTaikhoan.getText().clear();
            edMatKhau.getText().clear();
            vehicle = (Vehicle) data.getSerializableExtra("VEHICLE");
            user = (User) data.getSerializableExtra("USER");
            Intent intent = new Intent(DangNhapActivity.this,MainActivity.class);
            intent.putExtra("User",user);
            intent.putExtra("Vehicle",vehicle);
            startActivityForResult(intent,777);
        }

        if(requestCode == 777 && resultCode == Activity.RESULT_CANCELED) {
            finish();
        }

    }

    public void hideSoftKeyboard() {
        try {
            InputMethodManager inputMethodManager =
                    (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        } catch (NullPointerException ex) {
            ex.printStackTrace();
        }
    }

    private boolean checkDangnhap(String tk,String mk) {
        if(tk.isEmpty()) {
            tilTaikhoan.setError("Bạn chưa nhập tại khoản");
        }
        else{
            tilTaikhoan.setError(null);
        }

        if(mk.isEmpty()) {
            tilMatKhau.setError("Bạn chưa nhập mật khẩu");
        }
        else {
            tilMatKhau.setError(null);
        }
        if(tilMatKhau.getError() == null && tilTaikhoan.getError() == null){
            return true;
        }
        return false;
    }


}
