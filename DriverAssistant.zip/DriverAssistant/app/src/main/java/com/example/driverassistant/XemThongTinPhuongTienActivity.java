package com.example.driverassistant;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import API.Ac;
import API.Remind;
import API.RequestHandler;
import API.URL;
import API.User;
import API.Vehicle;
import adaptor.VehicleAdapter;
import cachoatdong.ChiPhiActivity;

public class XemThongTinPhuongTienActivity extends AppCompatActivity {

    private static final int REQUEST_XEM_CHI_TIET_PHUONG_TIEN = 155;

    private RecyclerView rvList;
    private VehicleAdapter vehicleAdapter;
    private User user;
    private List<Vehicle> vehicleList;
    private Intent intent;
    private Vehicle vehicle;
    private int vitri;
    private int positionV;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_xem_thong_tin_phuong_tien);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        rvList = (RecyclerView) findViewById(R.id.rv_xem_thong_tin_phuong_tien);

        intent = getIntent();
        user = (User) intent.getSerializableExtra("User");
        vehicle = (Vehicle) intent.getSerializableExtra("Vehicle");

        vehicleList = new ArrayList<>();
        vehicleAdapter = new VehicleAdapter(vehicleList,XemThongTinPhuongTienActivity.this);
        rvList.setHasFixedSize(true);
        rvList.setLayoutManager(new LinearLayoutManager(XemThongTinPhuongTienActivity.this,
                LinearLayoutManager.VERTICAL, false));
        rvList.addItemDecoration(new DividerItemDecoration(rvList.getContext()
                , DividerItemDecoration.VERTICAL));
        getVehicles(user.getUsername());
        rvList.setAdapter(vehicleAdapter);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();

        inflater.inflate(R.menu.menu_action_bar2, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        if (item.getItemId() == R.id.btn_add) {
            Intent intentA = new Intent(XemThongTinPhuongTienActivity.this,TaoPhuongTienActivity.class);
            intentA.putExtra("UseR",user);
            intentA.putExtra("DK",false);
            startActivityForResult(intentA,156);
        }

        return super.onOptionsItemSelected(item);
    }

    public void getVehicles(String user) {
        vehicleList.clear();
        StringRequest postRequest = new StringRequest(Request.Method.POST, URL.GET_VEHICLE_URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            if (jsonObject.getBoolean("status")) {
                                JSONArray result = jsonObject.getJSONArray("result");
                                for(int i = 0;i<result.length();i++) {
                                    JSONObject data = result.getJSONObject(i);
                                    Vehicle v = new Vehicle(data.getString("v_id"),
                                            data.getString("type"),
                                            data.getString("v_name"),
                                            data.getString("producer"),
                                            data.getInt("icon"),
                                            Float.parseFloat(data.getString("capacity")),
                                            data.getString("username"));
                                    if(v.getV_id().equals(vehicle.getV_id())) {
                                        vitri = i;
                                    }
                                    vehicleList.add(v);
                                }
                                vehicleAdapter.notifyDataSetChanged();
                            } else {
                                Toast.makeText(getBaseContext(), "Failed: " + jsonObject.getString("result"),
                                        Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(getBaseContext(), "Failed: " + error.toString(),
                                Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", user);
                return params;
            }
        };
        RequestHandler.getInstance(getBaseContext()).addToRequestQueue(postRequest);
    }

    public void moXemThongTinChiTietPhuongTien(int position) {
        positionV = position;
        Intent intent1 = new Intent(XemThongTinPhuongTienActivity.this,ThongTinChiTietPhuongTienActivity.class);
        intent1.putExtra("Vehicle",vehicleList.get(position));
        if(position == vitri) {
            intent1.putExtra("XD",true);
        } else {
            intent1.putExtra("XD",false);
        }
        startActivityForResult(intent1,155);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 155 && resultCode == Activity.RESULT_OK) {
            vehicleList.remove(positionV);
            vehicleList.add(positionV,(Vehicle) data.getSerializableExtra("VEHICLE"));
            vehicleAdapter.notifyDataSetChanged();
        } else if(requestCode == 155 && resultCode == Activity.RESULT_CANCELED) {
            vehicleList.remove(positionV);
            vehicleAdapter.notifyDataSetChanged();
        } else if(requestCode == 156 && resultCode == Activity.RESULT_OK) {
            finish();
            startActivity(getIntent());
        }
    }
}