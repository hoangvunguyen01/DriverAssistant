package adaptor;

public class TinhThanh {

    private String tinhThanh;
    private String sdt;

    public TinhThanh(String tinhThanh, String sdt) {
        this.tinhThanh = tinhThanh;
        this.sdt = sdt;
    }

    public String getTinhThanh() {
        return tinhThanh;
    }

    public void setTinhThanh(String tinhThanh) {
        this.tinhThanh = tinhThanh;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }
}
