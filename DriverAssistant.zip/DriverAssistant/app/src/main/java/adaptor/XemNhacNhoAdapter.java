package adaptor;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.driverassistant.R;

import java.util.List;

import API.Remind;
import giaodien.FragmentNhacNho;

public class XemNhacNhoAdapter extends RecyclerView.Adapter<XemNhacNhoAdapter.ViewHolder> {

    private FragmentNhacNho fragmentNhacNho;
    private List<Remind> list;

    public XemNhacNhoAdapter(FragmentNhacNho fragmentNhacNho, List<Remind> list) {
        this.fragmentNhacNho = fragmentNhacNho;
        this.list = list;
    }

    public void setList(List<Remind> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.layout_xem_nhac_nho_row_view, parent,
                false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvTen.setText(list.get(position).getType());
        holder.tvNgay.setText(list.get(position).getDate());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentNhacNho.moXemNhacNho(position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvTen;
        private TextView tvNgay;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTen   = (TextView) itemView.findViewById(R.id.tv_xem_nhac_nho_ten);
            tvNgay  = (TextView) itemView.findViewById(R.id.tv_xem_nhac_nho_ngay);
        }
    }
}
