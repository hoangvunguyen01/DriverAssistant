package adaptor;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.driverassistant.MainActivity;
import com.example.driverassistant.R;
import com.example.driverassistant.XemLichSuHoatDongActivity;

import java.util.List;

import API.Ac;
import giaodien.FragmentLichSu;

public class LichSuHoatDongAdapter extends RecyclerView.Adapter<LichSuHoatDongAdapter.ViewHolder> {

    private FragmentLichSu fragmentLichSu;
    private List<Ac> list;

    public LichSuHoatDongAdapter(FragmentLichSu fragmentLichSu, List<Ac> list) {
        this.fragmentLichSu = fragmentLichSu;
        this.list = list;
    }

    public void setList(List<Ac> list) {
        this.list = list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.layout_lich_su_hoat_dong_row_view, parent,
                false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Không hiển thị nhắc nhở lên lịch sử
        if (list.get(position).getName().equals("Đổ nhiên liệu")) {
            holder.imgLoaiHd.setImageResource(R.drawable.icon_gas_station2);
        } else if (list.get(position).getName().equals("Thay dung dịch")) {
            holder.imgLoaiHd.setImageResource(R.drawable.icon_motor_oil2);
        } else if (list.get(position).getName().equals("Thu nhập")) {
            holder.imgLoaiHd.setImageResource(R.drawable.icon_income2);
        } else if (list.get(position).getName().equals("Chi phí")) {
            holder.imgLoaiHd.setImageResource(R.drawable.icon_outcome2);
        } else if (list.get(position).getName().equals("Sửa chữa")) {
            holder.imgLoaiHd.setImageResource(R.drawable.icon_repair2);
        }

        holder.tvTen.setText(list.get(position).getName());
        holder.tvNgay.setText(list.get(position).getDate());
        holder.tvTongTien.setText(String.valueOf(list.get(position).getMoney()));


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentLichSu.moXemLichSuHoatDong(position);
            }
        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView imgLoaiHd;
        private TextView tvTen;
        private TextView tvNgay;
        private TextView tvTongTien;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            imgLoaiHd   = (ImageView) itemView.findViewById(R.id.img_lich_su_hd);
            tvTen       = (TextView) itemView.findViewById(R.id.tv_lich_su_hd_ten);
            tvNgay      = (TextView) itemView.findViewById(R.id.tv_lich_su_hd_ngay);
            tvTongTien  = (TextView) itemView.findViewById(R.id.tv_lich_su_hd_tong_tien);
        }
    }
}
