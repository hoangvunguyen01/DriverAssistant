package adaptor;

public class NSX {

    private String tenNsx;
    private int icon;

    public NSX(String tenNsx, int icon) {
        this.tenNsx = tenNsx;
        this.icon = icon;
    }

    public String getTenNsx() {
        return tenNsx;
    }

    public void setTenNsx(String tenNsx) {
        this.tenNsx = tenNsx;
    }

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }
}
