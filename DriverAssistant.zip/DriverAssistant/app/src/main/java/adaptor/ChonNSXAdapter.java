package adaptor;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.driverassistant.ChonNSXActivity;
import com.example.driverassistant.R;

import java.util.List;

public class ChonNSXAdapter extends RecyclerView.Adapter<ChonNSXAdapter.ViewHolder> {

    private List<NSX> nsxList;
    private ChonNSXActivity activity;

    public ChonNSXAdapter(List<NSX> nsxList, ChonNSXActivity activity) {
        this.nsxList = nsxList;
        this.activity = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.layout_chon_nsx_row_view, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvTen.setText(nsxList.get(position).getTenNsx());
        holder.imgIcon.setImageResource(nsxList.get(position).getIcon());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.traVeNSX(nsxList.get(position));
            }
        });
    }

    @Override
    public int getItemCount() {
        return nsxList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvTen;
        private ImageView imgIcon;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTen   = (TextView) itemView.findViewById(R.id.tv_danh_sach_nsx_ten);
            imgIcon = (ImageView) itemView.findViewById(R.id.img_danh_sach_nsx_icon);
        }
    }
}
