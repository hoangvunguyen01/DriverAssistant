package adaptor;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.driverassistant.GoiDienActivity;
import com.example.driverassistant.MainActivity;
import com.example.driverassistant.R;

import java.util.ArrayList;
import java.util.List;

public class GoiDienAdapter extends RecyclerView.Adapter<GoiDienAdapter.ViewHolder> implements Filterable {

    private List<TinhThanh> tinhThanhList;
    private List<TinhThanh> tinhThanhListFull;
    private GoiDienActivity activity;

    public GoiDienAdapter(List<TinhThanh> tinhThanhList, List<TinhThanh> tinhThanhListFull, GoiDienActivity activity) {
        this.tinhThanhList = tinhThanhList;
        this.tinhThanhListFull = tinhThanhListFull;
        this.activity = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.layout_goi_dien_row_view, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvTinhThanh.setText(tinhThanhList.get(position).getTinhThanh());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                activity.makePhoneCall(tinhThanhList.get(position).getSdt());
            }
        });
    }

    @Override
    public int getItemCount() {
        return tinhThanhList.size();
    }

    @Override
    public Filter getFilter() {
        return tinhThanhFilter;
    }

    private Filter tinhThanhFilter = new Filter() {
        @Override
        protected FilterResults performFiltering(CharSequence constraint) {
            List<TinhThanh> filteredList = new ArrayList<>();

            if (constraint == null || constraint.length() == 0) {
                filteredList.addAll(tinhThanhListFull);
            } else {
                String fillterPattern = constraint.toString().toLowerCase().trim();

                for (TinhThanh item : tinhThanhListFull) {
                    if (item.getTinhThanh().toLowerCase().contains(fillterPattern)) {
                        filteredList.add(item);
                    }
                }
            }

            FilterResults results = new FilterResults();
            results.values = filteredList;

            return results;
        }

        @Override
        protected void publishResults(CharSequence constraint, FilterResults results) {
                tinhThanhList.clear();
                tinhThanhList.addAll((List) results.values);
                notifyDataSetChanged();
        }
    };

    public class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvTinhThanh;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvTinhThanh = (TextView) itemView.findViewById(R.id.tv_ten_tinh_thanh_ho_tro);
        }
    }
}
