package adaptor;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.driverassistant.ChonPhuongTienActivity;
import com.example.driverassistant.MainActivity;
import com.example.driverassistant.R;
import com.example.driverassistant.ThongTinChiTietPhuongTienActivity;
import com.example.driverassistant.XemThongTinPhuongTienActivity;

import java.util.List;

import API.User;
import API.Vehicle;

public class VehicleAdapter extends RecyclerView.Adapter<VehicleAdapter.ViewHolder> {
    private List<Vehicle> items;
    private XemThongTinPhuongTienActivity context;

    public VehicleAdapter(List<Vehicle> items, XemThongTinPhuongTienActivity context) {
        this.items = items;
        this.context = context;

    }

    @NonNull
    @Override
    public VehicleAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View view = inflater.inflate(R.layout.layout_chon_phuong_tien,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VehicleAdapter.ViewHolder holder, int position) {
        Vehicle item = items.get(position);
        holder.tvTen.setText(item.getV_name());

        if(item.getIcon() == R.drawable.ic_honda_moto) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_honda_moto);
        } else if(item.getIcon() == R.drawable.ic_suzuki) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_suzuki);
        } else if(item.getIcon() == R.drawable.ic_sym) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_sym);
        } else if(item.getIcon() == R.drawable.ic_vinfast) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_vinfast);
        } else if(item.getIcon() == R.drawable.ic_yamaha) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_yamaha);
        } else if(item.getIcon() == R.drawable.ic_chevrolet) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_chevrolet);
        } else if(item.getIcon() == R.drawable.ic_ford) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_ford);
        } else if(item.getIcon() == R.drawable.ic_honda_oto) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_honda_oto);
        } else if(item.getIcon() == R.drawable.ic_huyndai) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_huyndai);
        } else if(item.getIcon() == R.drawable.ic_kia) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_kia);
        } else if(item.getIcon() == R.drawable.ic_toyota) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_toyota);
        } else if(item.getIcon() == R.drawable.ic_foton) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_foton);
        } else if(item.getIcon() == R.drawable.ic_hino) {
            holder.imgLoaiHd.setImageResource(R.drawable.ic_hino);
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.moXemThongTinChiTietPhuongTien(position);

            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvTen;
        public ImageView imgLoaiHd;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgLoaiHd   = (ImageView) itemView.findViewById(R.id.img_pt_loai_xe);
            tvTen       = (TextView) itemView.findViewById(R.id.tv_pt_ten_xe);
        }
    }
}
