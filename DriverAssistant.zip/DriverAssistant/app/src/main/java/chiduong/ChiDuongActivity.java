package chiduong;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Color;
import android.location.Location;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.driverassistant.NetWorkChangedListener;
import com.example.driverassistant.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.Cap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.Autocomplete;
import com.google.android.libraries.places.widget.model.AutocompleteActivityMode;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import docfilejson.ReadJSONDirection;
import docfilejson.ReadJSONNearbySearch;

public class ChiDuongActivity extends AppCompatActivity implements OnMapReadyCallback {

    public static final String API_KEY = "AIzaSyChwr7jNfENDYm2VRbi1ux92qn9O6VuAHo";
    public static final int AUTOCOMPLETE_DESTINATION = 1;

    private SupportMapFragment supportMapFragment;
    private GoogleMap myMap;
    private EditText edDestination;
    private TextView btnFindPath;
    private TextView tvDistance;
    private TextView tvTime;
    private List<Place.Field> fieldDestination;
    private LatLng destination;
    private LatLng yourLocation;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private boolean locationPermissionGranted = false;
    private Location lastLocation;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_duong);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        if (!Places.isInitialized()) {
            Places.initialize(ChiDuongActivity.this, API_KEY);
        }

        edDestination.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fieldDestination = Arrays.asList(Place.Field.NAME, Place.Field.LAT_LNG);

                Intent intent = new Autocomplete.IntentBuilder(AutocompleteActivityMode.OVERLAY
                        , fieldDestination).build(ChiDuongActivity.this);

                startActivityForResult(intent, AUTOCOMPLETE_DESTINATION);
            }
        });

        btnFindPath.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (edDestination.getText().toString().isEmpty()) {
                    Toast.makeText(ChiDuongActivity.this, "Bạn chưa chọn vị trí đến"
                            , Toast.LENGTH_SHORT).show();
                } else {
                    new ReadJSONDirection(ChiDuongActivity.this, yourLocation, destination).execute();
                }
            }
        });

        supportMapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.my_maps);
        supportMapFragment.getMapAsync(ChiDuongActivity.this);
    }

    private void AnhXa() {
        edDestination   = (EditText) findViewById(R.id.ed_destination);
        btnFindPath     = (TextView) findViewById(R.id.btn_find_path);
        tvDistance      = (TextView) findViewById(R.id.tv_distance);
        tvTime          = (TextView) findViewById(R.id.tv_time);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == AUTOCOMPLETE_DESTINATION && resultCode == RESULT_OK) {
            Place place = Autocomplete.getPlaceFromIntent(data);

            myMap.addMarker(new MarkerOptions()
                            .position(place.getLatLng())
                            .title(place.getName()));

            myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(place.getLatLng(), 18));

            destination = place.getLatLng();

            edDestination.setText(place.getName());
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        myMap = googleMap;

        try {
            // Customise the styling of the base map using a JSON object defined
            // in a raw resource file.
            boolean success = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(
                            this, R.raw.mapstyleaubergine));

            if (!success) {

            }
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }

        getLocationPermission();

    }

    public void callBackDataFromAsynctask(List<Route> data) {
        myMap.clear();

        for (int i = 0; i < data.size(); i++) {
            Route route = (Route) data.get(i);

            myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(route.endLocation, 18));

            myMap.addMarker(new MarkerOptions()
                    .position(route.endLocation)
                    .title(edDestination.getText().toString())
                    .snippet(route.endAddress));

            tvDistance.setText(route.distance.text);
            tvTime.setText(route.duration.text);

            PolylineOptions polylineOptions = new PolylineOptions()
                    .color(Color.RED)
                    .width(15);

            polylineOptions.addAll(route.points);

            myMap.addPolyline(polylineOptions);

        }
    }

    private void getLocationPermission() {
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationPermissionGranted = true;
            getCurrentLocation();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locationPermissionGranted = true;
            }
        }
        getCurrentLocation();
    }

    private void getCurrentLocation() {
        try{
            if (locationPermissionGranted) {
                Task<Location> locationResult = fusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if(task.isSuccessful()) {
                            lastLocation = task.getResult();
                            if(lastLocation != null) {
                                myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new
                                        LatLng(lastLocation.getLatitude(),lastLocation.getLongitude()),18));
                                yourLocation = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                                myMap.setMyLocationEnabled(true);
                            }
                        }
                    }
                });
            }
        }catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }
}