package chiduong;

public class Distance {

    public String text;
    public int values;

    public Distance(String text, int values) {
        this.text = text;
        this.values = values;
    }
}
