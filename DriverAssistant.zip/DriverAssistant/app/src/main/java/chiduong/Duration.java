package chiduong;

public class Duration {

    public String text;
    public int values;

    public Duration(String text, int values) {
        this.text = text;
        this.values = values;
    }
}
