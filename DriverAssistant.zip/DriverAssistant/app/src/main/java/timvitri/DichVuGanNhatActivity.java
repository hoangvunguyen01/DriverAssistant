package timvitri;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.Activity;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.location.Location;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;

import com.example.driverassistant.NetWorkChangedListener;
import com.example.driverassistant.R;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;

import java.util.List;

import docfilejson.ReadJSONNearbySearch;

public class DichVuGanNhatActivity extends AppCompatActivity implements OnMapReadyCallback {

    public static final String API_KEY = "AIzaSyChwr7jNfENDYm2VRbi1ux92qn9O6VuAHo";

    private SupportMapFragment supportMapFragment;
    private GoogleMap myMap;

    private LinearLayout linearGasStation;
    private LinearLayout linearATM;
    private LinearLayout linearBank;
    private LinearLayout linearRestaurant;
    private LinearLayout linearHospital;
    private LinearLayout linearHotel;
    private LinearLayout linearCinema;

    private FusedLocationProviderClient fusedLocationProviderClient;
    private boolean locationPermissionGranted = false;
    private Location lastLocation;

    private NetWorkChangedListener netWorkChangedListener = new NetWorkChangedListener();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dich_vu_gan_nhat);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        AnhXa();

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        if (!Places.isInitialized()) {
            Places.initialize(DichVuGanNhatActivity.this, API_KEY);
        }

        linearATM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastLocation != null) {
                    new ReadJSONNearbySearch(DichVuGanNhatActivity.this, new
                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude()),
                            "atm").execute();
                } else
                    getLocationPermission();
            }
        });

        linearBank.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastLocation != null) {
                    new ReadJSONNearbySearch(DichVuGanNhatActivity.this, new
                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude()),
                            "bank").execute();
                } else
                    getLocationPermission();
            }
        });

        linearHospital.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastLocation != null) {
                    new ReadJSONNearbySearch(DichVuGanNhatActivity.this, new
                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude()),
                            "hospital").execute();
                } else
                    getLocationPermission();
            }
        });

        linearHotel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastLocation != null) {
                    new ReadJSONNearbySearch(DichVuGanNhatActivity.this, new
                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude()),
                            "hotel").execute();
                } else
                    getLocationPermission();
            }
        });

        linearCinema.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastLocation != null) {
                    new ReadJSONNearbySearch(DichVuGanNhatActivity.this, new
                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude()),
                            "movie_theater").execute();
                } else
                    getLocationPermission();
            }
        });

        linearRestaurant.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastLocation != null) {
                    new ReadJSONNearbySearch(DichVuGanNhatActivity.this, new
                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude()),
                            "restaurant").execute();
                } else
                    getLocationPermission();
            }
        });

        linearGasStation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (lastLocation != null) {
                    new ReadJSONNearbySearch(DichVuGanNhatActivity.this, new
                            LatLng(lastLocation.getLatitude(), lastLocation.getLongitude()),
                            "gas_station").execute();
                } else
                    getLocationPermission();
            }
        });

        supportMapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.my_maps);
        supportMapFragment.getMapAsync(DichVuGanNhatActivity.this);
    }

    private void AnhXa() {
        linearGasStation         = (LinearLayout) findViewById(R.id.linear_gas_station);
        linearATM                = (LinearLayout) findViewById(R.id.linear_atm);
        linearBank               = (LinearLayout) findViewById(R.id.linear_bank);
        linearRestaurant         = (LinearLayout) findViewById(R.id.linear_restaurant);
        linearHospital           = (LinearLayout) findViewById(R.id.linear_hospital);
        linearHotel              = (LinearLayout) findViewById(R.id.linear_hotel);
        linearCinema             = (LinearLayout) findViewById(R.id.linear_cinema);
    }

    @Override
    protected void onStart() {
        IntentFilter filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(netWorkChangedListener, filter);
        super.onStart();
    }

    @Override
    protected void onStop() {
        unregisterReceiver(netWorkChangedListener);
        super.onStop();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        myMap = googleMap;

        try {
            // Customise the styling of the base map using a JSON object defined
            // in a raw resource file.
            boolean success = googleMap.setMapStyle(
                    MapStyleOptions.loadRawResourceStyle(
                            this, R.raw.mapstyleaubergine));

            if (!success) {

            }
        } catch (Resources.NotFoundException e) {
            e.printStackTrace();
        }

        getLocationPermission();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (item.getItemId() == android.R.id.home) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    public void callBackDataFromAsynctask(List<NearPlace> data) {
        myMap.clear();
        myMap.addMarker(new MarkerOptions()
                .position(new LatLng(lastLocation.getLatitude(),
                        lastLocation.getLongitude()))
                .title("You here"))
                .setIcon(BitmapDescriptorFactory.fromResource(R.drawable.icon_marker));

        for (int i = 0; i < data.size(); i++) {
            NearPlace nearPlace = data.get(i);
            MarkerOptions options = new MarkerOptions();
            options.position(nearPlace.nearplace);
            options.title(nearPlace.name);
            myMap.addMarker(options);
        }
        myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new
                LatLng(lastLocation.getLatitude(),lastLocation.getLongitude()),15));

    }

    private void getLocationPermission() {
        if (ContextCompat.checkSelfPermission(this.getApplicationContext(),
                android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            locationPermissionGranted = true;
            getCurrentLocation();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locationPermissionGranted = true;
            }
        }
        getCurrentLocation();
    }

    private void getCurrentLocation() {
        try{
            if (locationPermissionGranted) {
                Task<Location> locationResult = fusedLocationProviderClient.getLastLocation();
                locationResult.addOnCompleteListener(this, new OnCompleteListener<Location>() {
                    @Override
                    public void onComplete(@NonNull Task<Location> task) {
                        if(task.isSuccessful()) {
                            lastLocation = task.getResult();
                            if(lastLocation != null) {
                                myMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new
                                        LatLng(lastLocation.getLatitude(),lastLocation.getLongitude()),18));
                                myMap.setMyLocationEnabled(true);
                            }
                        }
                    }
                });
            }
        }catch (SecurityException e) {
            Log.e("Exception: %s", e.getMessage(), e);
        }
    }
}