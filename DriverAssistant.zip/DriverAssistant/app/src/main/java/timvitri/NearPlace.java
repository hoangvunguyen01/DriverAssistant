package timvitri;

import com.google.android.gms.maps.model.LatLng;

public class NearPlace {
    public String name;
    public LatLng nearplace;
}
