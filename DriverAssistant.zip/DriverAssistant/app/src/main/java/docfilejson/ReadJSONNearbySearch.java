package docfilejson;

import android.os.AsyncTask;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import timvitri.DichVuGanNhatActivity;
import timvitri.NearPlace;

public class ReadJSONNearbySearch extends AsyncTask<Void, Void, List<NearPlace>> {
    private static final String NEARBYSEARCH_URL_API = "https://maps.googleapis.com/maps/api/place/nearbysearch/json";

    private DichVuGanNhatActivity activity;
    private LatLng location;
    private String type;

    public ReadJSONNearbySearch(DichVuGanNhatActivity activity, LatLng location, String type) {
        this.activity = activity;
        this.location = location;
        this.type = type;
    }

    @Override
    protected List<NearPlace> doInBackground(Void... voids) {
        return getNearbySearchPlaces();
    }

    private List<NearPlace> getNearbySearchPlaces() {
        List<NearPlace> places = new ArrayList<>();
        StringBuilder data = new StringBuilder();

        try {
            URL url = new URL(getFileJSONNearbySearch());

            InputStreamReader inputStreamReader = new InputStreamReader(url.openConnection()
                    .getInputStream());

            BufferedReader reader = new BufferedReader(inputStreamReader);

            String line = "";

            while ((line = reader.readLine()) != null) {
                data.append(line);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            JSONObject jsonData = new JSONObject(data.toString());

            JSONArray jsonPlaces = jsonData.getJSONArray("results");

            for (int i = 0; i < jsonPlaces.length(); i++) {
                NearPlace place = new NearPlace();

                JSONObject jsonPlace = (JSONObject) jsonPlaces.get(i);
                JSONObject jsonGeometry = jsonPlace.getJSONObject("geometry");
                JSONObject jsonLocation = jsonGeometry.getJSONObject("location");

                place.name = jsonPlace.getString("name");
                place.nearplace = new LatLng(jsonLocation.getDouble("lat"),
                        jsonLocation.getDouble("lng"));
                places.add(place);
            }

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return places;
    }

    private String getFileJSONNearbySearch() {
        String file = NEARBYSEARCH_URL_API +"?location=" + location.latitude + "," +
                location.longitude + "&radius=5000" + "&types=" + type + "&sensor=true" +
                "&key=" + activity.API_KEY;
        return file;
    }

    @Override
    protected void onPostExecute(List<NearPlace> places) {
        super.onPostExecute(places);
        activity.callBackDataFromAsynctask(places);
    }
}
