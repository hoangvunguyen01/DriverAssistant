package docfilejson;

import android.os.AsyncTask;

import com.google.android.gms.maps.model.LatLng;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import chiduong.ChiDuongActivity;
import timvitri.DichVuGanNhatActivity;
import chiduong.Distance;
import chiduong.Duration;
import chiduong.Route;

public class ReadJSONDirection extends AsyncTask<String, Void, List<Route>> {

    private static final String DIRECTION_URL_API = "https://maps.googleapis.com/maps/api/directions/json?";

    private ChiDuongActivity activity;
    private LatLng origin;
    private LatLng des;

    public ReadJSONDirection(ChiDuongActivity activity, LatLng origin, LatLng des) {
        this.activity = activity;
        this.origin = origin;
        this.des = des;
    }

    @Override
    protected List<Route> doInBackground(String... strings) {
        return getDirectionData();
    }

    private List<Route> getDirectionData() {
        List<Route> routes = new ArrayList<>();
        StringBuilder data = new StringBuilder();

        try {
            URL url = new URL(getFileJSONDirection());

            InputStreamReader inputStreamReader = new InputStreamReader(url.openConnection()
                                                                        .getInputStream());

            BufferedReader reader = new BufferedReader(inputStreamReader);

            String line = "";

            while ((line = reader.readLine()) != null) {
                data.append(line);
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        try {
            JSONObject jsonData = new JSONObject(data.toString());

            JSONArray jsonRoutes = jsonData.getJSONArray("routes");

            for(int i = 0; i < jsonRoutes.length(); i++) {
                Route route = new Route();

                JSONObject jsonRoute = jsonRoutes.getJSONObject(i);

                JSONArray jsonLegs = jsonRoute.getJSONArray("legs");
                JSONObject jsonLeg = jsonLegs.getJSONObject(0);
                JSONObject jsonDistance = jsonLeg.getJSONObject("distance");
                JSONObject jsonDuration = jsonLeg.getJSONObject("duration");
                JSONObject jsonEndLocation = jsonLeg.getJSONObject("end_location");
                JSONObject jsonStartLocation = jsonLeg.getJSONObject("start_location");
                JSONObject overview_polyline = jsonRoute.getJSONObject("overview_polyline");

                route.distance = new Distance(jsonDistance.getString("text")
                        ,jsonDistance.getInt("value"));
                route.duration = new Duration(jsonDuration.getString("text")
                        ,jsonDuration.getInt("value"));
                route.endAddress = jsonLeg.getString("end_address");
                route.startAddress = jsonLeg.getString("start_address");
                route.endLocation = new LatLng(jsonEndLocation.getDouble("lat")
                        ,jsonEndLocation.getDouble("lng"));
                route.startLocation = new LatLng(jsonStartLocation.getDouble("lat")
                        ,jsonStartLocation.getDouble("lng"));

                route.points = decodePolyline(overview_polyline.getString("points"));

                routes.add(route);
            }


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return routes;
    }

    private String getFileJSONDirection() {
        String link = DIRECTION_URL_API + "origin=" + origin.latitude + ", " + origin.longitude
            + "&destination= " + des.latitude + ", " + des.longitude + "&key= " + activity.API_KEY;

        return link;
    }

    private List<LatLng> decodePolyline(String encode) {
        List<LatLng> polyList = new ArrayList<>();
        int index = 0;
        int len = encode.length();
        int lat = 0;
        int lng = 0;

        while (index < len) {
            int b;

            int shift = 0;
            int result = 0;
            do {
                b = encode.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encode.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng((((double) lat / 1E5)),
                    (((double) lng / 1E5)));
            polyList.add(p);
        }

        return polyList;
    }

    @Override
    protected void onPostExecute(List<Route> routes) {
        super.onPostExecute(routes);
        activity.callBackDataFromAsynctask(routes);
    }
}
