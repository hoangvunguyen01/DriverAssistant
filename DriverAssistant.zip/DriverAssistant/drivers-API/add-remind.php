<?php
    require "connection.php";
  
  $type = $_POST['type'];
  $date = $_POST['date'];
  $note = $_POST['note'];
  $v_id = $_POST['v_id'];

    $insert = "INSERT INTO remind(type,date,note,v_id) VALUES ('$type','$date','$note','$v_id')";

   	if(!mysqli_query($connect,$insert)){
   		die(json_encode(array('status' => false, 'result' => 'Thêm nhắc nhở không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Thêm nhắc nhở thành công thành công')));
?>