<?php
	require "connection.php";

	$r_id = $_POST['r_id'];
	$type = $_POST['type'];
	$date = $_POST['date'];
	$note = $_POST['note'];

	$update = "UPDATE remind SET type = '$type', date = '$date', note = '$note' WHERE r_id = '$r_id'";

	if(!mysqli_query($connect,$update)){
   		die(json_encode(array('status' => true, 'result' => 'Cập nhật nhắc nhở của bạn không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Cập nhật nhắc nhở của bạn thành công')));
?>