<?php
    require "connection.php";


  $v_id = $_POST['v_id'];

  $query = "SELECT * FROM remind WHERE v_id = '$v_id' and kt = 1";

  $data = mysqli_query($connect,$query);

  $result = array();
  while($row = mysqli_fetch_assoc($data)){
    $result[] = $row;
  }

  echo(json_encode(array('status' => true, 'result' => $result)));

?>