<?php
    require "connection.php";


  $username = $_POST['username'];
  $password = $_POST['password'];
  $fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];

    $insert = "INSERT INTO user VALUES ('$username','$password','$fullname','$email','$phone')";

   	if(!mysqli_query($connect,$insert)){
   		die(json_encode(array('status' => false, 'result' => 'Tạo tài khoản không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Tạo tài khoản thành công')));
?>