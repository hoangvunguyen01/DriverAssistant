<?php
    require "connection.php";


  $username = $_POST['username'];


  $query = "SELECT * FROM vehicle WHERE username = '$username' and kt = 1";

  $data = mysqli_query($connect,$query);

  $result = array();

  while($row = mysqli_fetch_assoc($data)){
    $result[] = $row;
  }

  // if(!isset($result['result'])){
  //   die(json_encode(array('status' => false, 'result' => "Hiện tại bạn không có xe nào")));
  // }

  echo(json_encode(array('status' => true, 'result' => $result)));

?>