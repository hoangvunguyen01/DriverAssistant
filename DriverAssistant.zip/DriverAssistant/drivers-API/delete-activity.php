<?php
    require "connection.php";

  $a_id = $_POST['a_id'];

  $delete = "UPDATE activity SET kt = 0 WHERE a_id = '$a_id'";

   	if(!mysqli_query($connect,$delete)){
   		die(json_encode(array('status' => false, 'result' => 'Xóa dữ liệu không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Xóa dữ liệu thành công')));
?>