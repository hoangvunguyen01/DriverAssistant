<?php
	$db = array(
		'server' => 'localhost',
		'username' => 'root',
		'password' => '',
		'dbname' => 'db_driverassistant'
	);
	
	$connect = mysqli_connect($db['server'],$db['username'],$db['password'],$db['dbname']);
	
	if(!$connect) {
		die('Kết nối không thành công'.mysqli_connect_error($connect));
	}
	
	mysqli_query($connect, "SET NAMES 'utf8'");
?>