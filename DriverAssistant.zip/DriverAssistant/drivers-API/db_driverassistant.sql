-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2021 at 02:52 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_driverassistant`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `a_id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date` varchar(10) NOT NULL,
  `time` varchar(20) NOT NULL,
  `odometer` float DEFAULT NULL,
  `type` varchar(100) NOT NULL,
  `price` float DEFAULT NULL,
  `money` float NOT NULL,
  `liter` float DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `v_id` varchar(11) NOT NULL,
  `kt` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`a_id`, `name`, `date`, `time`, `odometer`, `type`, `price`, `money`, `liter`, `location`, `note`, `v_id`, `kt`) VALUES
(44, 'Thu nhập', '05/05/2021', '09:55', 0, 'Vận chuyển hàng hóa', 0, 200000, 0, '', '', '51A-5774.33', 1),
(45, 'Đổ nhiên liệu', '03/05/2021', '09:15', 110, 'Xăng RON 95-IV', 19000, 25000, 1.05263, 'tram o Duong Pham hung', '', '51A-57364', 0);

-- --------------------------------------------------------

--
-- Table structure for table `province`
--

CREATE TABLE `province` (
  `name` varchar(30) NOT NULL,
  `phone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `province`
--

INSERT INTO `province` (`name`, `phone`) VALUES
('An Giang', '0733856214'),
('Bà Rịa - Vũng Tàu', '0966886272'),
('Bắc Giang', '0963828966'),
('Bắc Kạn', '0987246360'),
('Bạc Liêu', '0913990288'),
('Bắc Ninh', '0949737737'),
('Bến Tre', '0906357357'),
('Bình Dương', '0989111131'),
('Bình Phước', '0988213331'),
('Bình Thuận', '0918650108'),
('Bình Định', '0977755511'),
('Cà Mau', '07803818129'),
('Cần Thơ', '0908722722'),
('Cao Bằng', '0916661638'),
('Gia Lai', '0988949494'),
('Hà Giang', '0913271099'),
('Hà Nam', '0913989505'),
('Hà Nội', '0909116116'),
('Hà Tĩnh', '0972116116'),
('Hải Dương', '0942456116'),
('Hải Phòng', '0936940086'),
('Hậu Giang', '0941068068'),
('Hòa Bình', '0986217116'),
('Hưng Yên', '0995116116'),
('Khánh Hòa', '0975963535'),
('Kiên Giang', '0917888999'),
('Kon Tum', '0913437583'),
('Lai Châu', '0915333999'),
('Lâm Đồng', '0973116116'),
('Lạng Sơn', '0975116116'),
('Lào Cai', '0913323963'),
('Long An', '0933114784'),
('Nam Định', '0966444116'),
('Nghệ An', '0984164999'),
('Ninh Bình', '0982537537'),
('Ninh Thuận', '0908044212'),
('Phú Thọ', '0986673368'),
('Phú Yên', '0989810810'),
('Quảng Bình', '0937577555'),
('Quảng Nam', '0909119119'),
('Quảng Ngãi', '0914992479'),
('Quảng Ninh', '0967102666'),
('Quảng Trị', '0815514514'),
('Sóc Trăng', '0948700700'),
('Sơn La', '0914999116'),
('Tây Ninh', '0973567867'),
('Thái Bình', '0363839323'),
('Thái Nguyên', '0972321442'),
('Thanh Hóa', '0912582638'),
('Thừa Thiên Huế', '0905265693'),
('Tiền Giang', '0997118118'),
('Tp Hồ Chí Minh', '0909123123'),
('Trà Vinh', '0913969359'),
('Tuyên Quang', '0969358278'),
('Vĩnh Long', '0939404949'),
('Vĩnh Phúc', '0976110859'),
('Yên Bái', '0988184327'),
('Đà Nẵng', '0342117117'),
('Đắk Lắk', '0947457457'),
('Đắk Nông', '0969750750'),
('Điện Biên', '0912113114'),
('Đồng Nai', '0945117117'),
('Đồng Tháp', '0941068068');

-- --------------------------------------------------------

--
-- Table structure for table `remind`
--

CREATE TABLE `remind` (
  `r_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `date` varchar(10) NOT NULL,
  `note` varchar(255) DEFAULT NULL,
  `v_id` varchar(11) NOT NULL,
  `calender` int(11) NOT NULL,
  `kt` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `remind`
--

INSERT INTO `remind` (`r_id`, `type`, `date`, `note`, `v_id`, `calender`, `kt`) VALUES
(42, 'Đổ xăng', '09/05/2021', '', '51A-57364', 130, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(60) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `fullname`, `email`, `phone`) VALUES
('hoangvu', 'hoangvu', 'Nguyen Vo Hoang Vu', 'hoangvunguyen01@gmail.com', '0938972532'),
('truonganh', '123456', 'Nguyen Truong Anh', 'truonganh@gmail.com', '0938276512');

-- --------------------------------------------------------

--
-- Table structure for table `vehicle`
--

CREATE TABLE `vehicle` (
  `v_id` varchar(11) NOT NULL,
  `type` varchar(6) NOT NULL,
  `v_name` varchar(100) NOT NULL,
  `producer` varchar(100) NOT NULL,
  `icon` int(11) NOT NULL,
  `capacity` float NOT NULL,
  `username` varchar(100) NOT NULL,
  `kt` int(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vehicle`
--

INSERT INTO `vehicle` (`v_id`, `type`, `v_name`, `producer`, `icon`, `capacity`, `username`, `kt`) VALUES
('51A-431321', 'Xe máy', 'hondaa', 'Honda', 2131165338, 4.5, 'hoangvu', 0),
('51A-57364', 'Xe máy', 'feture', 'Honda', 2131165338, 4, 'hoangvu', 1),
('51A-5774.33', 'Xe hơi', 'Xe hoi', 'VinFast', 2131165382, 40, 'truonganh', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`a_id`),
  ADD KEY `activity_ibfk_1` (`v_id`);

--
-- Indexes for table `province`
--
ALTER TABLE `province`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `remind`
--
ALTER TABLE `remind`
  ADD PRIMARY KEY (`r_id`),
  ADD KEY `remind_ibfk_1` (`v_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `phone` (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD PRIMARY KEY (`v_id`),
  ADD KEY `vehicle_ibfk_1` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `a_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `remind`
--
ALTER TABLE `remind`
  MODIFY `r_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activity`
--
ALTER TABLE `activity`
  ADD CONSTRAINT `activity_ibfk_1` FOREIGN KEY (`v_id`) REFERENCES `vehicle` (`v_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `remind`
--
ALTER TABLE `remind`
  ADD CONSTRAINT `remind_ibfk_1` FOREIGN KEY (`v_id`) REFERENCES `vehicle` (`v_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vehicle`
--
ALTER TABLE `vehicle`
  ADD CONSTRAINT `vehicle_ibfk_1` FOREIGN KEY (`username`) REFERENCES `user` (`username`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
