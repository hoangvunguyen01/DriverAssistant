<?php
    require "connection.php";

  $r_id = $_POST['r_id'];

  $delete = "UPDATE remind SET kt = 0 WHERE r_id = '$r_id'";

   	if(!mysqli_query($connect,$delete)){
   		die(json_encode(array('status' => false, 'result' => 'Xóa dữ liệu không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Xóa dữ liệu thành công')));
?>