<?php
	require "connection.php";

	$a_id = $_POST['a_id'];
	$date = $_POST['date'];
	$time = $_POST['time'];
	$odometer = $_POST['odometer'];
	$type = $_POST['type'];
	$price = $_POST['price'];
	$money = $_POST['money'];
	$liter = $_POST['liter'];
	$location = $_POST['location'];
	$note = $_POST['note'];

	$update = "UPDATE activity SET date = '$date', time = '$time', odometer = '$odometer', type = '$type', price = '$price', money = '$money', liter = '$liter', location = '$location', note = '$note' WHERE a_id = '$a_id'";

	if(!mysqli_query($connect,$update)){
   		die(json_encode(array('status' => false, 'result' => 'Cập nhật hoạt động của bạn không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Cập nhật hoạt động của bạn thành công')));
?>