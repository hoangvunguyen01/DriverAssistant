<?php
    require "connection.php";


  $v_id = $_POST['v_id'];
  $type = $_POST['type'];
  $v_name = $_POST['v_name'];
  $producer = $_POST['producer'];
  $icon = $_POST['icon'];
  $capacity = $_POST['capacity'];
  $username = $_POST['username'];

    $insert = "INSERT INTO vehicle(v_id,type,v_name,producer,icon,capacity,username) VALUES ('$v_id','$type','$v_name','$producer','$icon','$capacity','$username')";

   	if(!mysqli_query($connect,$insert)){
   		die(json_encode(array('status' => false, 'result' => 'Thêm xe không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Thêm xe thành công')));
?>