<?php
	require "connection.php";

	$query = "SELECT * FROM province";

	$data = mysqli_query($connect,$query);

	$result = array();

	while($row = mysqli_fetch_assoc($data)){
		$result[] = $row;
	}
	
	echo(json_encode(array('status' => true, 'result' => $result)));

?>