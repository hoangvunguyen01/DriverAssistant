<?php
	require "connection.php";

	$username = $_POST['username'];
	$password = $_POST['password'];

	
	$query = "SELECT * FROM user WHERE username = '$username'";

	$data = mysqli_query($connect,$query);

	while($row = mysqli_fetch_assoc($data)){
		$result = $row;
	}

	if(!isset($result)){
		die(json_encode(array('status' => false, 'result' => "Tài khoản không tồn tại")));
	}

	if(strcmp($result['password'],$password)==0){
		echo(json_encode(array('status' => true, 'result' => $result)));
	}else {
		die(json_encode(array('status' => false, 'result' => "Mật khẩu không đúng")));
	}
	
?>