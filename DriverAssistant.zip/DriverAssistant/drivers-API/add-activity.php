<?php
    require "connection.php";
  
  $name = $_POST['name'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $odometer = $_POST['odometer'];
  $type = $_POST['type'];
  $price = $_POST['price'];
  $money = $_POST['money'];
  $liter = $_POST['liter'];
  $location = $_POST['location'];
  $note = $_POST['note'];
  $v_id = $_POST['v_id'];

    $insert = "INSERT INTO activity(name,date,time,odometer,type,price,money,liter,location,note,v_id) VALUES ('$name','$date','$time','$odometer','$type','$price','$money','$liter','$location','$note','$v_id')";

   	if(!mysqli_query($connect,$insert)){
   		die(json_encode(array('status' => false, 'result' => 'Thêm hoạt động không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Thêm hoạt động thành công')));
?>