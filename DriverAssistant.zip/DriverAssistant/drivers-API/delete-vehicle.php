<?php
    require "connection.php";


  $v_id = $_POST['v_id'];
  
  $delete = "UPDATE vehicle SET kt = 0 WHERE v_id = '$v_id'";

   	if(!mysqli_query($connect,$delete)){
   		die(json_encode(array('status' => false, 'result' => 'Xóa dữ liệu không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Xóa dữ liệu thành công')));
?>