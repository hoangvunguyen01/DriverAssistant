<?php
	require "connection.php";

	$v_id = $_POST['v_id'];
	$v_name = $_POST['v_name'];
	$capacity = $_POST['capacity'];

	$update = "UPDATE vehicle SET v_name = '$v_name', capacity = '$capacity' WHERE v_id = '$v_id'";

	if(!mysqli_query($connect,$update)){
   		die(json_encode(array('status' => false, 'result' => 'Cập nhật xe của bạn không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Cập nhật xe của bạn thành công')));
?>