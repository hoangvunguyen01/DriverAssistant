<?php
	require "connection.php";

	$username = $_POST['username'];
	$password = $_POST['password'];
	$fullname = $_POST['fullname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];

	$update = "UPDATE user SET fullname = '$fullname', password = '$password', email = '$email', phone ='$phone' WHERE username = '$username'";

	if(!mysqli_query($connect,$update)){
   		die(json_encode(array('status' => false, 'result' => 'Cập nhật tài khoản không thành công')));
   	}

   	echo(json_encode(array('status' => true, 'result' => 'Cập nhật tài khoản thành công')));
?>